<!-- Rio Adriano Arifin (202332007) - Desain Cerdas & Modern -->
<?php
session_start();
// Path ke koneksi.php disesuaikan
include '../config/koneksi.php';

// Ambil id_lapangan dari URL dan pastikan itu integer
$id_lapangan = isset($_GET['id_lapangan']) ? intval($_GET['id_lapangan']) : 0;

if ($id_lapangan <= 0) {
    $_SESSION['pesan_error'] = "ID Lapangan tidak valid!";
    header("Location: dashboard_lapangan.php");
    exit;
}

// Ambil info lapangan menggunakan prepared statement untuk keamanan
$stmt = $koneksi->prepare("SELECT * FROM lapangan WHERE id_lapangan = ?");
$stmt->bind_param("i", $id_lapangan);
$stmt->execute();
$result = $stmt->get_result();
$lapangan = $result->fetch_assoc();
$stmt->close();

if (!$lapangan) {
    $_SESSION['pesan_error'] = "Lapangan tidak ditemukan!";
    header("Location: dashboard_lapangan.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <title>Pesan Lapangan - <?= htmlspecialchars($lapangan['nama_lapangan']) ?></title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="../assets/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap');
    body {
      font-family: 'Inter', sans-serif;
      background-color: #e9ecef; /* Warna latar belakang lebih lembut */
    }
    .booking-wrapper {
      max-width: 800px; /* Sedikit lebih lebar untuk layout yang lebih baik */
      margin: 50px auto;
      animation: fadeIn 0.5s ease-out;
    }
    .booking-card {
      border: none;
      border-radius: 1rem;
      box-shadow: 0 10px 40px rgba(0,0,0,0.1);
      overflow: hidden;
      background-color: #fff;
    }
    .field-image {
      height: 280px;
      background-size: cover;
      background-position: center;
      position: relative;
      display: flex;
      align-items: flex-end;
      padding: 2rem;
    }
    .field-image::after {
      content: '';
      position: absolute;
      top: 0; left: 0; right: 0; bottom: 0;
      background: linear-gradient(to top, rgba(0,0,0,0.8), transparent);
    }
    .field-details {
      color: white;
      z-index: 2;
    }
    .field-details h2 {
      font-weight: 700;
      margin-bottom: 0.25rem;
    }
    .form-container {
      padding: 2.5rem;
    }
    /* PERBAIKAN: Style untuk setiap bagian form */
    .form-section {
        background-color: #f8f9fa;
        padding: 1.5rem;
        border-radius: .75rem;
        margin-bottom: 2rem;
    }
    .form-section h5 {
      font-weight: 600;
      color: #343a40;
      margin-bottom: 1rem;
    }
    .summary-section {
      background-color: #f8f9fa;
      padding: 1.5rem;
      border-radius: .75rem;
    }
    .total-price {
      font-size: 2.25rem;
      font-weight: 700;
      color: #0d6efd;
    }
    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(20px); }
      to { opacity: 1; transform: translateY(0); }
    }
  </style>
</head>
<body>

<div class="booking-wrapper">
  <div class="card booking-card">
    <div class="field-image" style="background-image: url('img/<?= htmlspecialchars($lapangan['gambar']) ?>');">
      <div class="field-details">
        <h2><?= htmlspecialchars($lapangan['nama_lapangan']) ?></h2>
        <p class="mb-0 fs-5"><span class="badge bg-light text-dark me-2"><?= htmlspecialchars($lapangan['jenis_lapangan']) ?></span> Rp <?= number_format($lapangan['harga_per_jam'], 0, ',', '.') ?> / jam</p>
      </div>
    </div>

    <div class="form-container">
      <form method="post" action="proses_booking.php">
        <input type="hidden" name="id_lapangan" value="<?= $id_lapangan ?>">
        <input type="hidden" id="harga_per_jam" value="<?= $lapangan['harga_per_jam'] ?>">

        <!-- Bagian Data Diri -->
        <div class="form-section">
            <h5><i class="bi bi-person-circle me-2"></i>1. Isi Data Diri Anda</h5>
            <div class="row">
              <div class="col-md-6 mb-3">
                <label class="form-label">Nama Lengkap</label>
                <input type="text" name="nama" class="form-control" placeholder="Masukkan nama lengkap" required>
              </div>
              <div class="col-md-6 mb-3">
                <label class="form-label">Email</label>
                <input type="email" name="email" class="form-control" placeholder="@gmail.com" required>
              </div>
              <div class="col-md-6 mb-3">
                <label class="form-label">No. HP Aktif</label>
                <input type="tel" name="no_hp" class="form-control" pattern="[0-9]{10,14}" title="Masukkan 10-14 digit angka" placeholder="08xxxx" required>
              </div>
            </div>
        </div>

        <!-- Bagian Pilih Jadwal -->
        <div class="form-section">
            <h5><i class="bi bi-calendar-event me-2"></i>2. Pilih Jadwal</h5>
            <div class="row">
              <div class="col-md-6 mb-3">
                <label class="form-label">Tanggal Booking</label>
                <input type="date" name="tanggal" id="tanggal" class="form-control" required min="<?= date('Y-m-d') ?>">
              </div>
            </div>
            <div class="alert alert-info small p-2">
                <i class="bi bi-info-circle-fill"></i> Silahkan pilih jadwal yang direncanakan.
            </div>
            <div class="row">
              <div class="col-md-6 mb-3">
                <label class="form-label">Jam Mulai</label>
                <select name="jam_mulai" id="jam_mulai" class="form-select" required>
                  <?php for($i=8; $i<=21; $i++): $jam = str_pad($i, 2, '0', STR_PAD_LEFT) . ":00"; ?>
                  <option value="<?= $jam ?>"><?= $jam ?></option>
                  <?php endfor; ?>
                </select>
              </div>
              <div class="col-md-6 mb-3">
                <label class="form-label">Jam Selesai</label>
                <select name="jam_selesai" id="jam_selesai" class="form-select" required>
                  <?php for($i=9; $i<=22; $i++): $jam = str_pad($i, 2, '0', STR_PAD_LEFT) . ":00"; ?>
                  <option value="<?= $jam ?>"><?= $jam ?></option>
                  <?php endfor; ?>
                </select>
              </div>
            </div>
        </div>
        
        <!-- Bagian Ringkasan -->
        <div class="summary-section">
            <h5 class="text-center mb-3">Ringkasan Biaya</h5>
            <div class="d-flex justify-content-between">
                <span class="text-muted">Durasi</span>
                <strong id="summary_durasi">-</strong>
            </div>
            <hr>
            <div class="text-center">
                <small class="text-muted">TOTAL</small>
                <div id="summary_total" class="total-price">Rp 0</div>
            </div>
        </div>

        <!-- Tombol Aksi -->
        <div class="d-flex justify-content-between mt-4">
          <a href="dashboard_lapangan.php" class="btn btn-outline-secondary"><i class="bi bi-arrow-left"></i> Kembali</a>
          <button type="submit" class="btn btn-primary btn-lg"><i class="bi bi-send-check"></i> Pesan & Lanjut Bayar</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const tanggalInput = document.getElementById('tanggal');
    const jamMulaiSelect = document.getElementById('jam_mulai');
    const jamSelesaiSelect = document.getElementById('jam_selesai');
    const idLapangan = <?= $id_lapangan ?>;
    const hargaPerJam = parseFloat(document.getElementById('harga_per_jam').value);

    const summaryDurasi = document.getElementById('summary_durasi');
    const summaryTotal = document.getElementById('summary_total');

    function fetchAndDisableTimes() {
        const tanggal = tanggalInput.value;
        
        // 1. Reset semua pilihan jam menjadi bisa diklik
        for (const option of jamMulaiSelect.options) { option.disabled = false; }
        for (const option of jamSelesaiSelect.options) { option.disabled = false; }
        
        if (!tanggal) return;

        fetch(`api_get_jadwal.php?id_lapangan=${idLapangan}&tanggal=${tanggal}`)
            .then(response => response.json())
            .then(data => {
                if (data.error) throw new Error(data.error);
                
                // 2. Nonaktifkan jam yang sudah terisi
                data.forEach(booking => {
                    const startHour = parseInt(booking.jam_mulai.split(':')[0]);
                    const endHour = parseInt(booking.jam_selesai.split(':')[0]);

                    for (let i = startHour; i < endHour; i++) {
                        const bookedHourStart = String(i).padStart(2, '0') + ':00';
                        const bookedHourEnd = String(i + 1).padStart(2, '0') + ':00';

                        const optionMulai = jamMulaiSelect.querySelector(`option[value="${bookedHourStart}"]`);
                        if (optionMulai) optionMulai.disabled = true;

                        const optionSelesai = jamSelesaiSelect.querySelector(`option[value="${bookedHourEnd}"]`);
                        if (optionSelesai) optionSelesai.disabled = true;
                    }
                });
            })
            .catch(error => {
                console.error('Error fetching schedule:', error);
                alert('Gagal memuat jadwal yang terisi. Silakan coba lagi.');
            });
    }

    function updateSummary() {
        const mulai = parseInt(jamMulaiSelect.value.split(':')[0]);
        const selesai = parseInt(jamSelesaiSelect.value.split(':')[0]);
        
        if (selesai > mulai && hargaPerJam > 0) {
            const durasi = selesai - mulai;
            summaryDurasi.textContent = `${durasi} jam`;
            const total = durasi * hargaPerJam;
            summaryTotal.textContent = 'Rp ' + total.toLocaleString('id-ID');
        } else {
            summaryDurasi.textContent = '0 jam';
            summaryTotal.textContent = 'Rp 0';
        }
    }

    tanggalInput.addEventListener('change', () => { fetchAndDisableTimes(); updateSummary(); });
    jamMulaiSelect.addEventListener('change', updateSummary);
    jamSelesaiSelect.addEventListener('change', updateSummary);

    updateSummary();
});
</script>

</body>
</html>
