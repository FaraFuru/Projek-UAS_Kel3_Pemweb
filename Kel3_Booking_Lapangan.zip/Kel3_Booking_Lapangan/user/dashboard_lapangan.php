<?php
include '../config/koneksi.php';

// Logika untuk menampilkan lapangan
$filter_jenis = isset($_GET['jenis']) ? $_GET['jenis'] : '';
$sort_harga = isset($_GET['sort']) ? $_GET['sort'] : '';

$params = [];
$types = '';
$query = "SELECT id_lapangan, nama_lapangan, jenis_lapangan, harga_per_jam, gambar, deskripsi FROM lapangan WHERE 1=1";

if (!empty($filter_jenis)) {
    $query .= " AND jenis_lapangan = ?";
    $params[] = $filter_jenis;
    $types .= 's';
}

if ($sort_harga == 'asc') {
    $query .= " ORDER BY harga_per_jam ASC";
} elseif ($sort_harga == 'desc') {
    $query .= " ORDER BY harga_per_jam DESC";
} else {
    $query .= " ORDER BY id_lapangan DESC";
}

$stmt = $koneksi->prepare($query);
if (!empty($types)) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$res_lapangan = $stmt->get_result();
$jenis_lapangan_list = $koneksi->query("SELECT DISTINCT jenis_lapangan FROM lapangan");

function format_deskripsi($text) {
    if (empty($text)) {
        return '<p>Tidak ada deskripsi detail untuk lapangan ini.</p>';
    }
    $lines = explode("\n", trim($text));
    $html = '';
    $in_list = false;
    foreach ($lines as $line) {
        $line = trim($line);
        if (substr($line, 0, 1) === '-') {
            if (!$in_list) {
                $html .= '<ul>';
                $in_list = true;
            }
            $html .= '<li>' . htmlspecialchars(trim(substr($line, 1))) . '</li>';
        } else {
            if ($in_list) {
                $html .= '</ul>';
                $in_list = false;
            }
            if (!empty($line)) {
                $html .= '<p>' . htmlspecialchars($line) . '</p>';
            }
        }
    }
    if ($in_list) {
        $html .= '</ul>';
    }
    return $html;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booking Lapangan GOR - Temukan Arena Terbaikmu!</title>
    <link rel="stylesheet" href="../assets/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap');
        body { 
            font-family: 'Poppins', sans-serif;
            background-color: #f9f9f9;
            overflow-x: hidden;
        }
        .navbar { background: rgba(0,0,0,0.5); transition: background 0.3s ease-in-out; }
        .navbar.scrolled { background: #212529; }
        .navbar-brand { font-weight: 700; }
        .hero-section { height: 50vh; background-image: linear-gradient(rgba(0,0,0,0.6), rgba(0,0,0,0.6)), url('../img/bg2.jpg'); background-size: cover; background-position: center; color: white; display: flex; align-items: center; justify-content: center; text-align: center; }
        .hero-section h1 { font-size: 3rem; font-weight: 700; text-shadow: 2px 2px 4px rgba(0,0,0,0.5); }
        .main-content { padding-top: 4rem; padding-bottom: 4rem; }
        .card-lapangan { border: none; border-radius: 1rem; overflow: hidden; box-shadow: 0 8px 25px rgba(0, 0, 0, 0.1); transition: transform 0.3s ease, box-shadow 0.3s ease; animation: fadeIn 0.5s ease-out forwards; display: flex; flex-direction: column; height: 100%; }
        .card-lapangan:hover { transform: translateY(-8px); box-shadow: 0 12px 30px rgba(0, 0, 0, 0.15); }
        .card-body { flex-grow: 1; display: flex; flex-direction: column; }
        .card-title { font-weight: 600; }
        .card-img-container { position: relative; overflow: hidden; }
        .lapangan-image { width: 100%; height: 250px; object-fit: cover; transition: transform 0.4s ease; }
        .card-lapangan:hover .lapangan-image { transform: scale(1.1); }
        .card-img-overlay { background: linear-gradient(to top, rgba(0,0,0,0.8), transparent); opacity: 0; transition: opacity 0.4s ease; display: flex; align-items: flex-end; justify-content: center; color: white; }
        .card-lapangan:hover .card-img-overlay { opacity: 1; }
        .modal-body ul { padding-left: 20px; }
        .modal-body li { margin-bottom: 0.5rem; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark fixed-top">
    <div class="container">
        <a class="navbar-brand" href="#">GOR Booking</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"><span class="navbar-toggler-icon"></span></button>
        <div class="collapse navbar-collapse" id="navbarNav"><ul class="navbar-nav ms-auto"><li class="nav-item"><a class="nav-link active" href="#">Home</a></li><li class="nav-item"><a class="nav-link" href="#lapangan">Daftar Lapangan</a></li></ul></div>
    </div>
</nav>

<header class="hero-section">
    <div class="container">
        <h1>Temukan & Booking Arena Olahraga Terbaik</h1>
        <p class="lead">Mulai petualangan olahragamu sekarang juga. Cepat, mudah, dan aman.</p>
    </div>
</header>

<main class="container main-content" id="lapangan">
    <div class="card shadow-sm mb-5 p-3">
        <form class="row g-3 align-items-center" method="GET" action="#lapangan">
            <div class="col-md"><label for="filterJenis" class="form-label">Jenis Lapangan</label><select id="filterJenis" name="jenis" class="form-select"><option value="">Semua Jenis</option><?php mysqli_data_seek($jenis_lapangan_list, 0); ?><?php while ($row = $jenis_lapangan_list->fetch_assoc()): ?><option value="<?= htmlspecialchars($row['jenis_lapangan']) ?>" <?= ($row['jenis_lapangan'] == $filter_jenis) ? 'selected' : '' ?>><?= htmlspecialchars($row['jenis_lapangan']) ?></option><?php endwhile; ?></select></div>
            <div class="col-md"><label for="sortHarga" class="form-label">Urutkan Harga</label><select id="sortHarga" name="sort" class="form-select"><option value="">Default</option><option value="asc" <?= ($sort_harga == 'asc') ? 'selected' : '' ?>>Termurah</option><option value="desc" <?= ($sort_harga == 'desc') ? 'selected' : '' ?>>Termahal</option></select></div>
            <div class="col-md-auto d-flex align-items-end"><button type="submit" class="btn btn-primary w-100"><i class="bi bi-search"></i> Cari</button></div>
            <div class="col-md-auto d-flex align-items-end"><a href="dashboard_lapangan.php#lapangan" class="btn btn-outline-secondary w-100"><i class="bi bi-arrow-counterclockwise"></i> Reset</a></div>
        </form>
    </div>

    <?php if (!empty($filter_jenis) || !empty($sort_harga)): ?>
        <div class="alert alert-info d-flex justify-content-between align-items-center">
            <span>
                <i class="bi bi-funnel-fill me-2"></i> Menampilkan hasil untuk:
                <?php if (!empty($filter_jenis)) echo "<strong>" . htmlspecialchars($filter_jenis) . "</strong>"; ?>
                <?php if (!empty($sort_harga)) echo " | Diurutkan: <strong>" . ($sort_harga == 'asc' ? 'Termurah' : 'Termahal') . "</strong>"; ?>
            </span>
            <a href="dashboard_lapangan.php#lapangan" class="btn-close" aria-label="Hapus Filter"></a>
        </div>
    <?php endif; ?>

    <div class="row g-4">
        <?php if ($res_lapangan->num_rows > 0): ?>
            <?php while ($lapangan = $res_lapangan->fetch_assoc()):
                $today = date('Y-m-d');
                $current_time = date('H:i:s');
                $id_lapangan = $lapangan['id_lapangan'];

                $stmt_booking = $koneksi->prepare("SELECT jam_mulai, jam_selesai FROM jadwal_booking WHERE id_lapangan = ? AND tanggal = ? AND status != 'batal' ORDER BY jam_mulai ASC");
                $stmt_booking->bind_param("is", $id_lapangan, $today);
                $stmt_booking->execute();
                $bookings_today = $stmt_booking->get_result();

                $is_available_now = true; $booked_until = null; $available_from = null;
                if ($bookings_today->num_rows > 0) {
                    foreach ($bookings_today as $booking) {
                        if ($current_time >= $booking['jam_mulai'] && $current_time < $booking['jam_selesai']) {
                            $is_available_now = false; $booked_until = $booking['jam_selesai']; break;
                        }
                        if ($current_time < $booking['jam_mulai']) {
                            $available_from = $booking['jam_mulai']; break;
                        }
                    }
                }
                $stmt_booking->close();
                $id_modal = 'detailModal-' . $id_lapangan;
            ?>
                <div class="col-md-6 col-lg-4">
                    <div class="card card-lapangan">
                        <div class="card-img-container">
                            <img src="img/<?= htmlspecialchars($lapangan['gambar']) ?>" onerror="this.onerror=null;this.src='https://placehold.co/600x400/EEE/31343C?text=Gambar+Rusak';" alt="<?= htmlspecialchars($lapangan['nama_lapangan']) ?>" class="lapangan-image">
                            <a href="create_booking.php?id_lapangan=<?= $lapangan['id_lapangan'] ?>" class="card-img-overlay text-decoration-none"><h5 class="fw-bold"><i class="bi bi-calendar-check-fill"></i> Pesan Sekarang</h5></a>
                        </div>
                        <div class="card-body">
                            <div>
                                <span class="badge bg-primary bg-opacity-10 text-primary mb-2"><?= htmlspecialchars($lapangan['jenis_lapangan']) ?></span>
                                <h5 class="card-title"><?= htmlspecialchars($lapangan['nama_lapangan']) ?></h5>
                                <p class="fs-5 fw-bold text-success mb-3">Rp <?= number_format($lapangan['harga_per_jam'], 0, ',', '.') ?> <span class="fs-6 fw-normal text-muted">/ jam</span></p>
                            </div>
                            
                            <div class="mt-auto">
                                <div class="alert <?= $is_available_now ? 'alert-success' : 'alert-warning' ?> p-2 text-center small mb-3">
                                    <i class="bi <?= $is_available_now ? 'bi-check-circle-fill' : 'bi-exclamation-triangle-fill' ?>"></i>
                                    <?php
                                        if (!$is_available_now && $booked_until) {
                                            echo "Tersedia setelah pkl. <strong>" . date('H:i', strtotime($booked_until)) . "</strong>";
                                        } elseif ($is_available_now && $available_from) {
                                            echo "Tersedia hingga pkl. <strong>" . date('H:i', strtotime($available_from)) . "</strong>";
                                        } else {
                                            echo "<strong>Tersedia</strong> hingga akhir hari";
                                        }
                                    ?>
                                </div>
                                <button type="button" class="btn btn-outline-dark w-100" data-bs-toggle="modal" data-bs-target="#<?= $id_modal ?>">
                                    <i class="bi bi-info-circle-fill"></i> Lihat Detail
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="modal fade" id="<?= $id_modal ?>" tabindex="-1" aria-labelledby="<?= $id_modal ?>Label" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h1 class="modal-title fs-5" id="<?= $id_modal ?>Label">Detail: <?= htmlspecialchars($lapangan['nama_lapangan']) ?></h1>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <?= format_deskripsi($lapangan['deskripsi']) ?>
                            </div>
                            <div class="modal-footer">
                                <a href="create_booking.php?id_lapangan=<?= $lapangan['id_lapangan'] ?>" class="btn btn-success"><i class="bi bi-calendar-check-fill"></i> Pesan Sekarang</a>
                            </div>
                        </div>
                    </div>
                </div>

            <?php endwhile; ?>
        <?php else: ?>
            <div class="col-12 text-center text-muted mt-5"><h4><i class="bi bi-search"></i> Oops!</h4><p>Tidak ada lapangan ditemukan sesuai kriteria Anda.</p></div>
        <?php endif; $stmt->close(); ?>
    </div>
</main>

<footer class="bg-dark text-white py-4">
    <div class="container text-center"><p class="mb-0">&copy; <?= date('Y') ?> GOR Booking by Kelompok 3. All Rights Reserved.</p></div>
</footer>

<script src="../assets/dist/js/bootstrap.bundle.min.js"></script>
<script>
    const navbar = document.querySelector('.navbar');
    window.addEventListener('scroll', () => {
        if (window.scrollY > 50) { navbar.classList.add('scrolled'); } 
        else { navbar.classList.remove('scrolled'); }
    });
</script>
</body>
</html>
