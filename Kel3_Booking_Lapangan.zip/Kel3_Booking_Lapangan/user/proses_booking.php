<?php
include '../config/koneksi.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama = $_POST['nama'];
    $email = $_POST['email'];
    $no_hp = $_POST['no_hp'];
    $id_lapangan = $_POST['id_lapangan'];
    $tanggal = $_POST['tanggal'];
    $jam_mulai = $_POST['jam_mulai'];
    $jam_selesai = $_POST['jam_selesai'];

    // Hitung durasi
    $durasi = (strtotime($jam_selesai) - strtotime($jam_mulai)) / 3600;

    if ($durasi <= 0 || floor($durasi) != $durasi) {
        echo "<script>
            alert('Durasi harus bilangan bulat dan minimal 1 jam.');
            window.history.back();
        </script>";
        exit;
    }

    // Validasi rentang waktu
    $mulai_int = (int)explode(':', $jam_mulai)[0];
    $selesai_int = (int)explode(':', $jam_selesai)[0];

    if ($mulai_int < 8 || $selesai_int > 22) {
        echo "<script>
            alert('Jam booking hanya diizinkan antara pukul 08:00 - 22:00.');
            window.history.back();
        </script>";
        exit;
    }

    // Cek bentrok jadwal
    $cek_bentrok = $koneksi->query("
        SELECT * FROM jadwal_booking
        WHERE id_lapangan = '$id_lapangan'
          AND tanggal = '$tanggal'
          AND (
              ('$jam_mulai' >= jam_mulai AND '$jam_mulai' < jam_selesai) OR
              ('$jam_selesai' > jam_mulai AND '$jam_selesai' <= jam_selesai) OR
              ('$jam_mulai' <= jam_mulai AND '$jam_selesai' >= jam_selesai)
          )
    ");

    if ($cek_bentrok->num_rows > 0) {
        echo "<script>
            alert('Lapangan sudah dibooking pada jam tersebut.');
            window.history.back();
        </script>";
        exit;
    }

    // Simpan atau ambil id_user
    $cek_user = $koneksi->query("SELECT id_user FROM users WHERE email = '$email'");
    if ($cek_user->num_rows > 0) {
        $user = $cek_user->fetch_assoc();
        $id_user = $user['id_user'];
    } else {
        // Hapus kolom `role` dari query INSERT
        $koneksi->query("
            INSERT INTO users (nama, email, no_hp)
            VALUES ('$nama', '$email', '$no_hp')
        ");
        $id_user = $koneksi->insert_id;
    }

    // Hitung total bayar
    $lap = $koneksi->query("SELECT harga_per_jam FROM lapangan WHERE id_lapangan = $id_lapangan")->fetch_assoc();
    $total_bayar = $lap['harga_per_jam'] * $durasi;

    // Simpan booking
    $koneksi->query("
        INSERT INTO jadwal_booking (
            id_user, id_lapangan, tanggal, jam_mulai, jam_selesai, total_bayar, status
        ) VALUES (
            '$id_user', 
            '$id_lapangan', 
            '$tanggal', 
            '$jam_mulai', 
            '$jam_selesai', 
            '$total_bayar', 
            'pending'
        )
    ");

    $id_booking = $koneksi->insert_id;

    // Redirect ke halaman konfirmasi pembayaran
    header("Location: konfirmasi_pembayaran.php?id=$id_booking");
    exit;
}
?>