<?php
session_start();
include '../config/koneksi.php';

// Ambil ID Booking dari URL
$id_booking = isset($_GET['id']) ? intval($_GET['id']) : 0;
if ($id_booking <= 0) { die("ID Booking tidak valid."); }

// Ambil detail booking dengan prepared statement
$stmt = $koneksi->prepare("
    SELECT b.id_user, b.id_lapangan, b.tanggal, b.jam_mulai, b.jam_selesai, b.total_bayar, l.nama_lapangan, b.created_at, b.status
    FROM jadwal_booking b
    JOIN lapangan l ON b.id_lapangan = l.id_lapangan
    WHERE b.id_booking = ?
");
$stmt->bind_param("i", $id_booking);
$stmt->execute();
$booking = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$booking) { die("Booking tidak ditemukan."); }

// PERBAIKAN: Logika Waktu yang Lebih Akurat
date_default_timezone_set('Asia/Jakarta');
$waktu_dibuat = strtotime($booking['created_at']);
$waktu_kedaluwarsa = $waktu_dibuat + (15 * 60); // Batas waktu 15 menit
$waktu_sekarang = time();
$sisa_detik = $waktu_kedaluwarsa - $waktu_sekarang;

// Cek di sisi server apakah waktu sudah habis
if ($sisa_detik <= 0 && $booking['status'] == 'pending') {
    $stmt_cancel = $koneksi->prepare("UPDATE jadwal_booking SET status = 'batal' WHERE id_booking = ?");
    $stmt_cancel->bind_param("i", $id_booking);
    $stmt_cancel->execute();
    $stmt_cancel->close();
    $booking['status'] = 'batal';
}

// Generate nomor Virtual Account unik
$virtual_account = "8808" . str_pad($id_booking, 8, "0", STR_PAD_LEFT);

// PERBAIKAN: Ambil nomor telepon Super Admin secara dinamis
$superadmin_phone = '08552722345'; // Nomor fallback
$result_admin = $koneksi->query("SELECT no_telp_admin FROM admin WHERE role = 'superadmin' LIMIT 1");
if ($result_admin && $result_admin->num_rows > 0) {
    $admin_data = $result_admin->fetch_assoc();
    if (!empty($admin_data['no_telp_admin'])) {
        $superadmin_phone = $admin_data['no_telp_admin'];
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <title>Konfirmasi Pembayaran</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../assets/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <style>
      @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap');
      body { font-family: 'Inter', sans-serif; background-color: #f0f2f5; }
      .payment-wrapper { max-width: 550px; margin: 50px auto; animation: fadeIn 0.5s ease-out; }
      .payment-card { border: none; border-radius: 1rem; box-shadow: 0 10px 40px rgba(0,0,0,0.1); }
      .timer-box { font-size: 2rem; font-weight: 700; color: #dc3545; }
      .va-box { background-color: #e9ecef; border-radius: .5rem; }
      .va-number { font-size: 1.5rem; font-weight: 600; letter-spacing: 2px; }
      @keyframes fadeIn {
        from { opacity: 0; transform: translateY(20px); }
        to { opacity: 1; transform: translateY(0); }
      }
    </style>
</head>
<body>

<div class="payment-wrapper">
  <div class="card payment-card">
    <div class="card-body p-4 p-md-5 text-center">
      
      <?php if ($booking['status'] == 'pending'): ?>
        <!-- Tampilan jika waktu masih ada -->
        <i class="bi bi-hourglass-split text-primary fs-1"></i>
        <h3 class="fw-bold mt-3">Selesaikan Pembayaran</h3>
        <p class="text-muted">Batas waktu pembayaran Anda akan berakhir dalam:</p>
        <div id="timer" class="timer-box mb-4">--:--</div>

        <div class="text-start">
            <p>Silakan lakukan transfer ke nomor Virtual Account di bawah ini:</p>
            <div class="va-box p-3 text-center mb-3">
                <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/a/ac/Old_Bank_Central_Asia_logo.svg/2560px-Old_Bank_Central_Asia_logo.svg.png" height="20" alt="BCA Logo" class="mb-2">
                <p class="mb-1 small">Nomor Virtual Account</p>
                <p class="va-number mb-0"><?= htmlspecialchars($virtual_account) ?></p>
            </div>
            <div class="alert alert-warning small">
                <strong>PENTING:</strong> Pastikan jumlah transfer sesuai dengan total tagihan agar pembayaran dapat diproses.
            </div>
            <ul class="list-group list-group-flush">
              <li class="list-group-item d-flex justify-content-between align-items-center px-0">
                Total Tagihan
                <strong class="fs-5 text-primary">Rp <?= number_format($booking['total_bayar'], 0, ',', '.') ?></strong>
              </li>
              <li class="list-group-item px-0 text-muted small">
                <strong>Detail:</strong> <?= htmlspecialchars($booking['nama_lapangan']) ?> pada <?= date('d M Y', strtotime($booking['tanggal'])) ?>, pukul <?= date('H:i', strtotime($booking['jam_mulai'])) ?>.
              </li>
            </ul>

            <!-- PERBAIKAN: Menambahkan blok garansi dan kontak -->
            <div class="alert alert-success mt-4" role="alert">
                <h5 class="alert-heading fw-bold"><i class="bi bi-shield-check"></i> Garansi Layanan</h5>
                <p class="mb-1 small">Kami menjamin pesanan Anda akan diproses. Jika verifikasi tidak dilakukan dalam 15 menit setelah Anda mengunggah bukti, uang Anda akan kembali 100%.</p>
                <hr>
                <p class="mb-0 small">Ada kendala? Hubungi Admin di: <strong><?= htmlspecialchars($superadmin_phone) ?></strong></p>
            </div>
        </div>
        <a href="../pembayaran/buat_pembayaran.php?id=<?= $id_booking ?>" id="uploadButton" class="btn btn-primary btn-lg w-100 mt-4">
            <i class="bi bi-cloud-arrow-up-fill me-2"></i>Saya Sudah Bayar, Upload Bukti
        </a>
      
      <?php else: ?>
        <!-- Tampilan jika waktu sudah habis atau status bukan pending -->
        <i class="bi bi-x-circle-fill text-danger fs-1"></i>
        <h3 class="fw-bold mt-3">Waktu Pembayaran Habis</h3>
        <p class="text-muted mb-4">Maaf, waktu untuk pembayaran booking #<?= $id_booking ?> telah berakhir dan booking Anda telah dibatalkan secara otomatis.</p>
        <a href="dashboard_lapangan.php" class="btn btn-outline-secondary w-100">Cari Jadwal Lain</a>
      <?php endif; ?>

    </div>
  </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const timerElement = document.getElementById('timer');
    if (timerElement) {
        let remainingSeconds = <?= $sisa_detik ?>;

        const interval = setInterval(() => {
            if (remainingSeconds <= 0) {
                clearInterval(interval);
                window.location.reload();
                return;
            }
            
            remainingSeconds--; 
            
            const minutes = Math.floor(remainingSeconds / 60);
            const seconds = remainingSeconds % 60;
            timerElement.textContent = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;

        }, 1000);
    }
});
</script>

</body>
</html>
