<?php
header('Content-Type: application/json');
session_start();
include '../config/koneksi.php';

// Hanya izinkan metode POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405); // Method Not Allowed
    echo json_encode(['error' => 'Metode tidak diizinkan.']);
    exit;
}

// Ambil data JSON dari body request
$data = json_decode(file_get_contents('php://input'), true);
$id_booking = isset($data['id_booking']) ? intval($data['id_booking']) : 0;
$status = isset($data['status']) ? $data['status'] : '';

if ($id_booking > 0 && ($status == 'batal')) {
    // Hanya izinkan update ke status 'batal' melalui API ini untuk keamanan
    $stmt = $koneksi->prepare("UPDATE jadwal_booking SET status = ? WHERE id_booking = ? AND status = 'pending'");
    $stmt->bind_param("si", $status, $id_booking);
    
    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Status berhasil diupdate.']);
    } else {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Gagal mengupdate status.']);
    }
    $stmt->close();
} else {
    http_response_code(400); // Bad Request
    echo json_encode(['success' => false, 'message' => 'Data tidak valid.']);
}

$koneksi->close();
?>
