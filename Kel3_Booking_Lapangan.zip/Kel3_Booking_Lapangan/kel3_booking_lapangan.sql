-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 30, 2025 at 04:58 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kel3_booking_lapangan`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id_admin` int(11) NOT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `role` enum('superadmin','admin') DEFAULT 'admin',
  `nama_admin` varchar(100) NOT NULL,
  `email_admin` varchar(100) NOT NULL,
  `no_telp_admin` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id_admin`, `username`, `password`, `role`, `nama_admin`, `email_admin`, `no_telp_admin`) VALUES
(7, 'FaraFuru', '$2y$10$R45mmM8szAkYvEVAdepYMO7gNIUkp5udMVyhAxN4Q.EgE5tWcFdIe', 'admin', 'Admin Gadungan', 'admin7@example.com', '081234567890'),
(8, 'superadmin', '$2y$10$bW.E/ztRpAw7mcJaHiTJS.QeGCUxCoQsxYjJbrNvKib9GuRTvOvp.', 'superadmin', 'Lord Sepuh', 'admin8@example.com', '081234567890'),
(9, 'admin', '$2y$10$0JbWPAYq1..BBVE0Rjh5W.VMbwBGN/7qq9ToSrn6ibJIvEuvyIx6i', 'admin', 'Admin Test', 'admin9@example.com', '081234567890'),
(10, 'rio', '$2y$10$hUiQoQtuY5qc7oAGxaxCc.P7zrmnA6O1EiBKXUEsxGtteHpBjqDBS', 'admin', 'Rio Adriano Arifin', 'rio2332007@itpln.ac.id', '08552722345'),
(13, 'albert', '$2y$10$aGXxUh0chT.wGFyNFN5X.eqr1vfQXI4yALPunye6SZ7d/DHNu6k9O', 'admin', 'Albert', 'albert@gmail.com', '081575005333');

-- --------------------------------------------------------

--
-- Table structure for table `jadwal_booking`
--

CREATE TABLE `jadwal_booking` (
  `id_booking` int(11) NOT NULL,
  `id_user` int(11) DEFAULT NULL,
  `id_lapangan` int(11) DEFAULT NULL,
  `tanggal` date DEFAULT NULL,
  `jam_mulai` time DEFAULT NULL,
  `jam_selesai` time DEFAULT NULL,
  `total_bayar` decimal(10,0) DEFAULT NULL,
  `status` enum('pending','dibayar','batal') DEFAULT 'pending',
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `jadwal_booking`
--

INSERT INTO `jadwal_booking` (`id_booking`, `id_user`, `id_lapangan`, `tanggal`, `jam_mulai`, `jam_selesai`, `total_bayar`, `status`, `created_at`) VALUES
(12, 1, 6, '2025-06-27', '08:00:00', '09:00:00', 65000, 'batal', '2025-06-27 17:23:58'),
(13, 1, 6, '2025-06-27', '10:00:00', '12:00:00', 130000, 'batal', '2025-06-27 17:23:58'),
(14, 1, 6, '2025-06-27', '13:00:00', '15:00:00', 130000, 'pending', '2025-06-27 17:24:27'),
(15, 1, 6, '2025-06-27', '15:00:00', '17:00:00', 130000, 'pending', '2025-06-27 17:27:21'),
(16, 7, 7, '2025-06-28', '13:00:00', '17:00:00', 320000, 'dibayar', '2025-06-27 18:00:53');

-- --------------------------------------------------------

--
-- Table structure for table `lapangan`
--

CREATE TABLE `lapangan` (
  `id_lapangan` int(11) NOT NULL,
  `nama_lapangan` varchar(100) NOT NULL,
  `jenis_lapangan` varchar(50) DEFAULT NULL,
  `harga_per_jam` decimal(10,0) NOT NULL,
  `gambar` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `lapangan`
--

INSERT INTO `lapangan` (`id_lapangan`, `nama_lapangan`, `jenis_lapangan`, `harga_per_jam`, `gambar`) VALUES
(1, 'Cahaya Surya', 'Basket', 50000, '685e78e3d50be-ピナケス - 「原神」Happy 2nd Anniversary (101546011) .jpg'),
(3, 'Kuda Lumping', 'Bola', 100000, '685e5de133594-Hoshino.Ichika.(Project.Sekai).full.4233571.png'),
(4, 'Jaka Tingkir', 'Sepak Bola', 75000, '6861f56f0d421-16948166361664214166.jpg'),
(5, 'Buto Ijo', 'Tenis', 40000, '685e5a5aeb46d-EVJSr_YU8AI-VLp.jpeg'),
(6, 'Malin Kundang', 'Voli', 65000, '685e5a73ee024-Bobathory - Raiden x Sara (100501860) .jpg'),
(7, 'Fufufafa', 'Bowling', 80000, '6861f5204a1b8-pngtree-an-image-of-a-bowling-alley-with-pink-lighting-image_2679709.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `pembayaran`
--

CREATE TABLE `pembayaran` (
  `id_pembayaran` int(11) NOT NULL,
  `id_booking` int(11) DEFAULT NULL,
  `metode_pembayaran` varchar(50) DEFAULT NULL,
  `tanggal_bayar` datetime DEFAULT NULL,
  `jumlah_bayar` decimal(10,0) DEFAULT NULL,
  `bukti_transfer` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id_user` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `no_hp` varchar(20) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id_user`, `nama`, `email`, `no_hp`, `password`) VALUES
(1, 'Rio Adriano Arifin', 'rioadrianoa@gmail.com', '08552722345', 'default123'),
(2, 'Rio Adriano Arifin', 'rioadrianoa@gmail.com', '08552722345', 'default123'),
(3, 'Rio', 'rio2332007@itpln.ac.id', '08552722345', 'default123'),
(4, 'Aji', 'farafuruha@gmail.com', '08552722345', 'default123'),
(5, 'Rio Adriano Arifin', 'rioadrianoa@gmail.com', '08552722345', 'default123'),
(6, 'Aji', 'farafuruha@gmail.com', '08552722345', 'default123'),
(7, 'wowo', 'farafuru410@gmail.com', '08552722345', NULL),
(8, 'dd', 'dd@gmail.com', 'dd', '$2y$10$9gCJvWrvODT9xYt/Q3wEr.lEPeIjRRR5.DLM/Wn1XUkwhTLDlo1nm');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id_admin`),
  ADD UNIQUE KEY `email_admin` (`email_admin`);

--
-- Indexes for table `jadwal_booking`
--
ALTER TABLE `jadwal_booking`
  ADD PRIMARY KEY (`id_booking`),
  ADD KEY `id_user` (`id_user`),
  ADD KEY `id_lapangan` (`id_lapangan`);

--
-- Indexes for table `lapangan`
--
ALTER TABLE `lapangan`
  ADD PRIMARY KEY (`id_lapangan`);

--
-- Indexes for table `pembayaran`
--
ALTER TABLE `pembayaran`
  ADD PRIMARY KEY (`id_pembayaran`),
  ADD KEY `id_booking` (`id_booking`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id_admin` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `jadwal_booking`
--
ALTER TABLE `jadwal_booking`
  MODIFY `id_booking` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `lapangan`
--
ALTER TABLE `lapangan`
  MODIFY `id_lapangan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `pembayaran`
--
ALTER TABLE `pembayaran`
  MODIFY `id_pembayaran` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `jadwal_booking`
--
ALTER TABLE `jadwal_booking`
  ADD CONSTRAINT `jadwal_booking_ibfk_1` FOREIGN KEY (`id_user`) REFERENCES `users` (`id_user`),
  ADD CONSTRAINT `jadwal_booking_ibfk_2` FOREIGN KEY (`id_lapangan`) REFERENCES `lapangan` (`id_lapangan`);

--
-- Constraints for table `pembayaran`
--
ALTER TABLE `pembayaran`
  ADD CONSTRAINT `pembayaran_ibfk_1` FOREIGN KEY (`id_booking`) REFERENCES `jadwal_booking` (`id_booking`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
