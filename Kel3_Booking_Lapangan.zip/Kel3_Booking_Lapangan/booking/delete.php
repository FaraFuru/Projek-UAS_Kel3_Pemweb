<!-- Rio Adriano Arifin (202332007) - Ditingkatkan -->
<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: ../admin/login_admin.php');
    exit;
}
include '../config/koneksi.php';

if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $id = $_GET['id'];
    
    // PERBAIKAN: Gunakan prepared statement untuk keamanan
    $stmt = $koneksi->prepare("DELETE FROM jadwal_booking WHERE id_booking = ?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        $_SESSION['pesan_sukses'] = "Booking berhasil dihapus.";
    } else {
        $_SESSION['pesan_error'] = "Gagal menghapus booking.";
    }
    $stmt->close();
} else {
    $_SESSION['pesan_error'] = "ID booking tidak valid.";
}

header("Location: read.php");
exit;
?>
