<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: ../admin/login_admin.php');
    exit;
}
include '../config/koneksi.php';

$error_message = '';

if (isset($_POST['simpan'])) {
    $nama = $_POST['nama'];
    $email = $_POST['email'];
    $no_hp = $_POST['no_hp'];
    $id_lapangan = $_POST['id_lapangan'];
    $tanggal = $_POST['tanggal'];
    $jam_mulai = $_POST['jam_mulai'];
    $jam_selesai = $_POST['jam_selesai'];

    if (!preg_match('/^[0-9]{10,14}$/', $no_hp)) {
        $error_message = "Format Nomor HP tidak valid. Hanya angka, 10-14 digit.";
    } else {
        $durasi = (strtotime($jam_selesai) - strtotime($jam_mulai)) / 3600;
        if ($durasi <= 0) {
            $error_message = "Jam selesai harus setelah jam mulai.";
        } elseif (empty($nama) || empty($email) || empty($no_hp) || empty($id_lapangan) || empty($tanggal)) {
            $error_message = "Semua field wajib diisi.";
        } else {
            $koneksi->begin_transaction();
            try {
                $stmt_cek = $koneksi->prepare("SELECT id_booking FROM jadwal_booking WHERE id_lapangan = ? AND tanggal = ? AND status != 'batal' AND (? < jam_selesai AND ? > jam_mulai)");
                $stmt_cek->bind_param("isss", $id_lapangan, $tanggal, $jam_mulai, $jam_selesai);
                $stmt_cek->execute();
                if ($stmt_cek->get_result()->num_rows > 0) {
                    throw new Exception("Jadwal bentrok! Lapangan sudah dibooking pada jam tersebut.");
                }
                $stmt_cek->close();

                $id_user = null;
                $stmt_user = $koneksi->prepare("SELECT id_user FROM users WHERE email = ?");
                $stmt_user->bind_param("s", $email);
                $stmt_user->execute();
                $res_user = $stmt_user->get_result();
                if ($res_user->num_rows > 0) {
                    $id_user = $res_user->fetch_assoc()['id_user'];
                } else {
                    $default_pass = password_hash("default123", PASSWORD_DEFAULT);
                    $stmt_new_user = $koneksi->prepare("INSERT INTO users (nama, email, no_hp, password) VALUES (?, ?, ?, ?)");
                    $stmt_new_user->bind_param("ssss", $nama, $email, $no_hp, $default_pass);
                    $stmt_new_user->execute();
                    $id_user = $stmt_new_user->insert_id;
                    $stmt_new_user->close();
                }
                $stmt_user->close();
                
                $stmt_lap = $koneksi->prepare("SELECT harga_per_jam FROM lapangan WHERE id_lapangan = ?");
                $stmt_lap->bind_param("i", $id_lapangan);
                $stmt_lap->execute();
                $harga_per_jam = $stmt_lap->get_result()->fetch_assoc()['harga_per_jam'];
                $total_bayar = $harga_per_jam * $durasi;
                $stmt_lap->close();

                // PERBAIKAN UTAMA: Status untuk booking offline (admin) adalah 'pending'
                $stmt_booking = $koneksi->prepare("INSERT INTO jadwal_booking (id_user, id_lapangan, tanggal, jam_mulai, jam_selesai, total_bayar, status) VALUES (?, ?, ?, ?, ?, ?, 'pending')");
                $stmt_booking->bind_param("iisssd", $id_user, $id_lapangan, $tanggal, $jam_mulai, $jam_selesai, $total_bayar);
                $stmt_booking->execute();
                $stmt_booking->close();

                $koneksi->commit();
                $_SESSION['pesan_sukses'] = "Booking offline berhasil ditambahkan dengan status 'Pending'.";
                header("Location: read.php");
                exit;

            } catch (Exception $e) {
                $koneksi->rollback();
                $error_message = $e->getMessage();
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Booking</title>
    <link rel="stylesheet" href="../assets/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <style>
        body { display: flex; min-height: 100vh; background-color: #f8f9fa; }
        .sidebar { width: 280px; background: #212529; color: white; position: fixed; height: 100%; padding-top: 1rem; }
        .sidebar .nav-link { color: #adb5bd; font-size: 1rem; padding: 0.75rem 1.5rem; transition: all 0.3s; }
        .sidebar .nav-link:hover, .sidebar .nav-link.active { background-color: #495057; color: white; border-left: 4px solid #0d6efd; }
        .main-content { margin-left: 280px; padding: 2rem; width: calc(100% - 280px); }
        .jadwal-info-box { background-color: #e9ecef; border-radius: .5rem; }
        .summary-card .total-price { font-size: 1.75rem; font-weight: bold; color: #198754; }
    </style>
</head>
<body>

<?php include '../admin/templates/sidebar.php'; ?>

<div class="main-content">
    <div class="d-flex justify-content-between align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Tambah Booking Manual</h1>
    </div>

    <div class="row">
        <div class="col-lg-8">
            <div class="card shadow-sm">
                <div class="card-body p-4">
                    <?php if (!empty($error_message)): ?>
                        <div class="alert alert-danger"><?= $error_message ?></div>
                    <?php endif; ?>
                    <form method="post">
                        <h5><i class="bi bi-person"></i> Data Pemesan</h5>
                        <hr class="mt-2 mb-3">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Nama</label>
                                <input type="text" name="nama" class="form-control" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Email</label>
                                <input type="email" name="email" class="form-control" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">No HP</label>
                                <input type="tel" name="no_hp" class="form-control" pattern="[0-9]{10,14}" title="Masukkan 10-14 digit angka" required>
                            </div>
                        </div>

                        <h5 class="mt-4"><i class="bi bi-calendar-check"></i> Data Booking</h5>
                        <hr class="mt-2 mb-3">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Pilih Lapangan</label>
                                <select name="id_lapangan" id="id_lapangan" class="form-select" required>
                                    <option value="" data-harga="0" data-jenis="" disabled selected>-- Pilih Lapangan --</option>
                                    <?php
                                    $lapangan_res = $koneksi->query("SELECT * FROM lapangan ORDER BY nama_lapangan ASC");
                                    while ($l = $lapangan_res->fetch_assoc()) {
                                        echo "<option value='{$l['id_lapangan']}' data-harga='{$l['harga_per_jam']}' data-jenis='" . htmlspecialchars($l['jenis_lapangan']) . "'>{$l['nama_lapangan']} (Rp " .
                                              number_format($l['harga_per_jam'], 0, ',', '.') . "/jam)</option>";
                                    }
                                    ?>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Tanggal Booking</label>
                                <input type="date" name="tanggal" id="tanggal" class="form-control" required min="<?= date('Y-m-d') ?>">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Jam Mulai</label>
                                <select name="jam_mulai" id="jam_mulai" class="form-select" required>
                                    <?php for($i=8; $i<=21; $i++): $jam = str_pad($i, 2, '0', STR_PAD_LEFT) . ":00"; ?>
                                    <option value="<?= $jam ?>"><?= $jam ?></option>
                                    <?php endfor; ?>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Jam Selesai</label>
                                <select name="jam_selesai" id="jam_selesai" class="form-select" required>
                                    <?php for($i=9; $i<=22; $i++): $jam = str_pad($i, 2, '0', STR_PAD_LEFT) . ":00"; ?>
                                    <option value="<?= $jam ?>"><?= $jam ?></option>
                                    <?php endfor; ?>
                                </select>
                            </div>
                        </div>

                        <div class="d-flex justify-content-between mt-4">
                            <a href="read.php" class="btn btn-secondary"><i class="bi bi-x-circle"></i> Batal</a>
                            <button type="submit" name="simpan" class="btn btn-primary"><i class="bi bi-check-circle-fill"></i> Simpan Booking</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="card shadow-sm mb-4">
                <div class="card-header bg-info text-white">
                    <h5 class="mb-0"><i class="bi bi-clock-history me-2"></i>Jadwal Terisi</h5>
                </div>
                <div class="card-body jadwal-info-box" id="jadwal-info">
                    <p class="text-muted text-center p-3">Pilih lapangan dan tanggal untuk melihat jadwal.</p>
                </div>
            </div>
            <div class="card shadow-sm summary-card">
                <div class="card-header bg-success text-white">
                    <h5 class="mb-0"><i class="bi bi-receipt-cutoff me-2"></i>Ringkasan Booking</h5>
                </div>
                <div class="card-body">
                    <div class="mb-2">
                        <strong>Lapangan:</strong>
                        <span id="summary_lapangan" class="float-end">-</span>
                    </div>
                    <div class="mb-2">
                        <strong>Jenis:</strong>
                        <span id="summary_jenis" class="float-end">-</span>
                    </div>
                    <div class="mb-2">
                        <strong>Tanggal:</strong>
                        <span id="summary_tanggal" class="float-end">-</span>
                    </div>
                    <div class="mb-2">
                        <strong>Durasi:</strong>
                        <span id="summary_durasi" class="float-end">-</span>
                    </div>
                    <hr>
                    <div class="text-center">
                        <small class="text-muted">TOTAL BAYAR</small>
                        <div id="summary_total" class="total-price">Rp 0</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="../assets/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const lapanganSelect = document.getElementById('id_lapangan');
    const tanggalInput = document.getElementById('tanggal');
    const jamMulaiSelect = document.getElementById('jam_mulai');
    const jamSelesaiSelect = document.getElementById('jam_selesai');
    const jadwalInfoDiv = document.getElementById('jadwal-info');

    // Elemen untuk Ringkasan
    const summaryLapangan = document.getElementById('summary_lapangan');
    const summaryJenis = document.getElementById('summary_jenis');
    const summaryTanggal = document.getElementById('summary_tanggal');
    const summaryDurasi = document.getElementById('summary_durasi');
    const summaryTotal = document.getElementById('summary_total');

    function fetchJadwal() {
        const idLapangan = lapanganSelect.value;
        const tanggal = tanggalInput.value;
        jadwalInfoDiv.innerHTML = '<p class="text-muted text-center p-3">Memuat jadwal...</p>';
        if (!idLapangan || !tanggal) {
            jadwalInfoDiv.innerHTML = '<p class="text-muted text-center p-3">Pilih lapangan dan tanggal.</p>';
            return;
        }
        fetch(`api_get_jadwal.php?id_lapangan=${idLapangan}&tanggal=${tanggal}`)
            .then(response => response.json())
            .then(data => {
                if (data.error) throw new Error(data.error);
                if (data.length === 0) {
                    jadwalInfoDiv.innerHTML = '<div class="alert alert-success p-2 text-center small m-3">Semua jam tersedia!</div>';
                } else {
                    let html = '<ul class="list-group list-group-flush">';
                    data.forEach(booking => {
                        html += `<li class="list-group-item d-flex justify-content-between align-items-center small p-2">Pukul ${booking.jam_mulai.substring(0, 5)} - ${booking.jam_selesai.substring(0, 5)} <span class="badge bg-danger rounded-pill">Terisi</span></li>`;
                    });
                    html += '</ul>';
                    jadwalInfoDiv.innerHTML = html;
                }
            })
            .catch(error => {
                jadwalInfoDiv.innerHTML = '<p class="text-danger text-center p-3">Gagal memuat jadwal.</p>';
                console.error('Error:', error);
            });
    }

    function updateSummary() {
        const selectedLapanganOption = lapanganSelect.options[lapanganSelect.selectedIndex];
        
        summaryLapangan.textContent = selectedLapanganOption.value ? selectedLapanganOption.text.split(' (')[0] : '-';
        summaryJenis.textContent = selectedLapanganOption.value ? selectedLapanganOption.getAttribute('data-jenis') : '-';
        
        summaryTanggal.textContent = tanggalInput.value ? new Date(tanggalInput.value).toLocaleDateString('id-ID', {day:'numeric', month:'long', year:'numeric'}) : '-';

        const mulai = parseInt(jamMulaiSelect.value.split(':')[0]);
        const selesai = parseInt(jamSelesaiSelect.value.split(':')[0]);
        const hargaPerJam = parseFloat(selectedLapanganOption.getAttribute('data-harga'));
        
        if (selesai > mulai && hargaPerJam > 0) {
            const durasi = selesai - mulai;
            summaryDurasi.textContent = `${durasi} jam`;
            const total = durasi * hargaPerJam;
            summaryTotal.textContent = 'Rp ' + total.toLocaleString('id-ID');
        } else {
            summaryDurasi.textContent = '0 jam';
            summaryTotal.textContent = 'Rp 0';
        }
    }

    // Event Listeners
    lapanganSelect.addEventListener('change', () => { fetchJadwal(); updateSummary(); });
    tanggalInput.addEventListener('change', () => { fetchJadwal(); updateSummary(); });
    jamMulaiSelect.addEventListener('change', updateSummary);
    jamSelesaiSelect.addEventListener('change', updateSummary);

    // Panggil sekali saat load untuk inisialisasi
    updateSummary();
});
</script>
</body>
</html>
