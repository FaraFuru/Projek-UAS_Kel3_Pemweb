<!-- Rio Adriano Arifin (202332007) - Ditingkatkan & Interaktif -->
<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: ../admin/login_admin.php');
    exit;
}
include '../config/koneksi.php';

// Validasi ID
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: read.php");
    exit;
}
$id_booking = intval($_GET['id']);

// Ambil data booking awal dengan prepared statement
$stmt = $koneksi->prepare("
    SELECT b.*, u.nama, u.email, u.no_hp
    FROM jadwal_booking b 
    JOIN users u ON b.id_user = u.id_user
    WHERE b.id_booking = ?
");
$stmt->bind_param("i", $id_booking);
$stmt->execute();
$result = $stmt->get_result();
$data = $result->fetch_assoc();
$stmt->close();

if (!$data) {
    $_SESSION['pesan_error'] = "Booking tidak ditemukan!";
    header("Location: read.php");
    exit;
}

$error_message = '';
// Proses update
if (isset($_POST['update'])) {
    $id_lapangan = $_POST['id_lapangan'];
    $tanggal = $_POST['tanggal'];
    $jam_mulai = $_POST['jam_mulai'];
    $jam_selesai = $_POST['jam_selesai'];
    
    $durasi = (strtotime($jam_selesai) - strtotime($jam_mulai)) / 3600;
    if($durasi <= 0) {
        $error_message = "Durasi tidak valid!";
    } else {
        $koneksi->begin_transaction();
        try {
            // Cek jadwal bentrok, KECUALI booking ini sendiri
            $stmt_cek = $koneksi->prepare("SELECT id_booking FROM jadwal_booking WHERE id_lapangan = ? AND tanggal = ? AND status != 'batal' AND id_booking != ? AND (? < jam_selesai AND ? > jam_mulai)");
            $stmt_cek->bind_param("isiss", $id_lapangan, $tanggal, $id_booking, $jam_mulai, $jam_selesai);
            $stmt_cek->execute();
            if ($stmt_cek->get_result()->num_rows > 0) {
                throw new Exception("Jadwal bentrok dengan booking lain!");
            }
            $stmt_cek->close();

            // Hitung ulang total bayar
            $stmt_lap = $koneksi->prepare("SELECT harga_per_jam FROM lapangan WHERE id_lapangan = ?");
            $stmt_lap->bind_param("i", $id_lapangan);
            $stmt_lap->execute();
            $harga_per_jam = $stmt_lap->get_result()->fetch_assoc()['harga_per_jam'];
            $total_bayar = $harga_per_jam * $durasi;
            $stmt_lap->close();
            
            // Update DB
            $stmt_update = $koneksi->prepare("UPDATE jadwal_booking SET id_lapangan = ?, tanggal = ?, jam_mulai = ?, jam_selesai = ?, total_bayar = ? WHERE id_booking = ?");
            $stmt_update->bind_param("isssdi", $id_lapangan, $tanggal, $jam_mulai, $jam_selesai, $total_bayar, $id_booking);
            $stmt_update->execute();
            $stmt_update->close();

            $koneksi->commit();
            $_SESSION['pesan_sukses'] = "Booking #$id_booking berhasil diperbarui!";
            header("Location: read.php");
            exit;
        } catch (Exception $e) {
            $koneksi->rollback();
            $error_message = $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Booking #<?= $id_booking ?></title>
    <link rel="stylesheet" href="../assets/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <style>
        body { display: flex; min-height: 100vh; background-color: #f8f9fa; }
        .sidebar { width: 280px; background: #212529; color: white; position: fixed; height: 100%; padding-top: 1rem; }
        .sidebar .nav-link { color: #adb5bd; font-size: 1rem; padding: 0.75rem 1.5rem; transition: all 0.3s; }
        .sidebar .nav-link:hover, .sidebar .nav-link.active { background-color: #495057; color: white; border-left: 4px solid #0d6efd; }
        .main-content { margin-left: 280px; padding: 2rem; width: calc(100% - 280px); }
        .jadwal-info-box { background-color: #e9ecef; border-radius: .5rem; }
        .summary-card .total-price { font-size: 1.75rem; font-weight: bold; color: #198754; }
    </style>
</head>
<body>

<?php include '../admin/templates/sidebar.php'; ?>

<div class="main-content">
    <div class="d-flex justify-content-between align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Edit Booking #<?= $id_booking ?></h1>
    </div>

    <div class="row">
        <div class="col-lg-8">
            <div class="card shadow-sm">
                <div class="card-body p-4">
                    <?php if (!empty($error_message)): ?>
                        <div class="alert alert-danger"><?= $error_message ?></div>
                    <?php endif; ?>
                    <div class="alert alert-light">
                        <strong>Pemesan:</strong> <?= htmlspecialchars($data['nama']) ?> (<?= htmlspecialchars($data['email']) ?>)
                    </div>
                    <form method="post">
                        <h5 class="mt-4"><i class="bi bi-calendar-check"></i> Edit Data Booking</h5>
                        <hr class="mt-2 mb-3">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Pilih Lapangan</label>
                                <select name="id_lapangan" id="id_lapangan" class="form-select" required>
                                    <?php
                                    $lapangan_res = $koneksi->query("SELECT * FROM lapangan ORDER BY nama_lapangan ASC");
                                    while ($l = $lapangan_res->fetch_assoc()) {
                                        $selected = ($l['id_lapangan'] == $data['id_lapangan']) ? 'selected' : '';
                                        echo "<option value='{$l['id_lapangan']}' data-harga='{$l['harga_per_jam']}' data-jenis='" . htmlspecialchars($l['jenis_lapangan']) . "' $selected>{$l['nama_lapangan']} (Rp " .
                                              number_format($l['harga_per_jam'], 0, ',', '.') . "/jam)</option>";
                                    }
                                    ?>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Tanggal Booking</label>
                                <input type="date" name="tanggal" id="tanggal" class="form-control" value="<?= htmlspecialchars($data['tanggal']) ?>" required min="<?= date('Y-m-d') ?>">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Jam Mulai</label>
                                <select name="jam_mulai" id="jam_mulai" class="form-select" required>
                                    <?php for($i=8; $i<=21; $i++): $jam = str_pad($i, 2, '0', STR_PAD_LEFT) . ":00"; ?>
                                    <option value="<?= $jam ?>" <?= (substr($data['jam_mulai'], 0, 5) == $jam) ? 'selected' : '' ?>><?= $jam ?></option>
                                    <?php endfor; ?>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Jam Selesai</label>
                                <select name="jam_selesai" id="jam_selesai" class="form-select" required>
                                    <?php for($i=9; $i<=22; $i++): $jam = str_pad($i, 2, '0', STR_PAD_LEFT) . ":00"; ?>
                                    <option value="<?= $jam ?>" <?= (substr($data['jam_selesai'], 0, 5) == $jam) ? 'selected' : '' ?>><?= $jam ?></option>
                                    <?php endfor; ?>
                                </select>
                            </div>
                        </div>

                        <div class="d-flex justify-content-between mt-4">
                            <a href="read.php" class="btn btn-secondary"><i class="bi bi-x-circle"></i> Batal</a>
                            <button type="submit" name="update" class="btn btn-warning"><i class="bi bi-save"></i> Simpan Perubahan</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="card shadow-sm mb-4">
                <div class="card-header bg-info text-white"><h5 class="mb-0"><i class="bi bi-clock-history me-2"></i>Jadwal Terisi</h5></div>
                <div class="card-body jadwal-info-box" id="jadwal-info"><p class="text-muted text-center p-3">Pilih lapangan dan tanggal.</p></div>
            </div>
            <div class="card shadow-sm summary-card">
                <div class="card-header bg-success text-white"><h5 class="mb-0"><i class="bi bi-receipt-cutoff me-2"></i>Ringkasan Booking</h5></div>
                <div class="card-body">
                    <div class="mb-2"><strong>Lapangan:</strong><span id="summary_lapangan" class="float-end">-</span></div>
                    <div class="mb-2"><strong>Jenis:</strong><span id="summary_jenis" class="float-end">-</span></div>
                    <div class="mb-2"><strong>Tanggal:</strong><span id="summary_tanggal" class="float-end">-</span></div>
                    <div class="mb-2"><strong>Durasi:</strong><span id="summary_durasi" class="float-end">-</span></div>
                    <hr>
                    <div class="text-center"><small class="text-muted">TOTAL BAYAR</small><div id="summary_total" class="total-price">Rp 0</div></div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="../assets/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const lapanganSelect = document.getElementById('id_lapangan');
    const tanggalInput = document.getElementById('tanggal');
    const jamMulaiSelect = document.getElementById('jam_mulai');
    const jamSelesaiSelect = document.getElementById('jam_selesai');
    const jadwalInfoDiv = document.getElementById('jadwal-info');
    const idBookingToExclude = <?= $id_booking ?>;

    const summaryLapangan = document.getElementById('summary_lapangan');
    const summaryJenis = document.getElementById('summary_jenis');
    const summaryTanggal = document.getElementById('summary_tanggal');
    const summaryDurasi = document.getElementById('summary_durasi');
    const summaryTotal = document.getElementById('summary_total');

    function fetchJadwal() {
        const idLapangan = lapanganSelect.value;
        const tanggal = tanggalInput.value;
        jadwalInfoDiv.innerHTML = '<p class="text-muted text-center p-3">Memuat jadwal...</p>';
        if (!idLapangan || !tanggal) {
            jadwalInfoDiv.innerHTML = '<p class="text-muted text-center p-3">Pilih lapangan dan tanggal.</p>';
            return;
        }
        fetch(`api_get_jadwal.php?id_lapangan=${idLapangan}&tanggal=${tanggal}&exclude_id=${idBookingToExclude}`)
            .then(response => response.json())
            .then(data => {
                if (data.error) throw new Error(data.error);
                if (data.length === 0) {
                    jadwalInfoDiv.innerHTML = '<div class="alert alert-success p-2 text-center small m-3">Semua jam tersedia!</div>';
                } else {
                    let html = '<ul class="list-group list-group-flush">';
                    data.forEach(booking => {
                        html += `<li class="list-group-item d-flex justify-content-between align-items-center small p-2">Pukul ${booking.jam_mulai.substring(0, 5)} - ${booking.jam_selesai.substring(0, 5)} <span class="badge bg-danger rounded-pill">Terisi</span></li>`;
                    });
                    html += '</ul>';
                    jadwalInfoDiv.innerHTML = html;
                }
            })
            .catch(error => {
                jadwalInfoDiv.innerHTML = '<p class="text-danger text-center p-3">Gagal memuat jadwal.</p>';
                console.error('Error:', error);
            });
    }

    function updateSummary() {
        const selectedOption = lapanganSelect.options[lapanganSelect.selectedIndex];
        summaryLapangan.textContent = selectedOption.value ? selectedOption.text.split(' (')[0] : '-';
        summaryJenis.textContent = selectedOption.value ? selectedOption.getAttribute('data-jenis') : '-';
        summaryTanggal.textContent = tanggalInput.value ? new Date(tanggalInput.value).toLocaleDateString('id-ID', {day:'numeric', month:'long', year:'numeric'}) : '-';

        const mulai = parseInt(jamMulaiSelect.value.split(':')[0]);
        const selesai = parseInt(jamSelesaiSelect.value.split(':')[0]);
        const hargaPerJam = parseFloat(selectedOption.getAttribute('data-harga'));
        
        if (selesai > mulai && hargaPerJam >= 0) {
            const durasi = selesai - mulai;
            summaryDurasi.textContent = `${durasi} jam`;
            summaryTotal.textContent = 'Rp ' + (durasi * hargaPerJam).toLocaleString('id-ID');
        } else {
            summaryDurasi.textContent = '0 jam';
            summaryTotal.textContent = 'Rp 0';
        }
    }

    lapanganSelect.addEventListener('change', () => { fetchJadwal(); updateSummary(); });
    tanggalInput.addEventListener('change', () => { fetchJadwal(); updateSummary(); });
    jamMulaiSelect.addEventListener('change', updateSummary);
    jamSelesaiSelect.addEventListener('change', updateSummary);

    // Panggil sekali saat load untuk inisialisasi
    fetchJadwal();
    updateSummary();
});
</script>
</body>
</html>
