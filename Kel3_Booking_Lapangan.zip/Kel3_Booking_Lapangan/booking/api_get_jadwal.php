<?php
// PERBAIKAN: Memastikan tidak ada output lain yang merusak JSON
ob_start(); // Mulai output buffering

include '../config/koneksi.php';

// Validasi input
if (!isset($_GET['id_lapangan']) || !isset($_GET['tanggal'])) {
    ob_end_clean(); // Hapus buffer jika ada error
    http_response_code(400); // Bad Request
    echo json_encode(['error' => 'Parameter tidak lengkap']);
    exit;
}

$id_lapangan = intval($_GET['id_lapangan']);
$tanggal = $_GET['tanggal'];

// Ambil data jadwal yang sudah dibooking dengan prepared statement
$stmt = $koneksi->prepare("
    SELECT jam_mulai, jam_selesai 
    FROM jadwal_booking 
    WHERE id_lapangan = ? AND tanggal = ? AND status != 'batal'
    ORDER BY jam_mulai ASC
");

if ($stmt === false) {
    ob_end_clean();
    http_response_code(500);
    echo json_encode(['error' => 'Gagal menyiapkan query.']);
    exit;
}

$stmt->bind_param("is", $id_lapangan, $tanggal);
$stmt->execute();
$result = $stmt->get_result();

$jadwal_terisi = [];
while ($row = $result->fetch_assoc()) {
    $jadwal_terisi[] = $row;
}

$stmt->close();
$koneksi->close();

ob_end_clean(); // Hapus buffer sebelum mengirim JSON
header('Content-Type: application/json');
echo json_encode($jadwal_terisi);
?>
