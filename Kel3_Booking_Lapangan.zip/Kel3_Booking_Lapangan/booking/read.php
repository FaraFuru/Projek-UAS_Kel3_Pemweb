<!-- Rio Adriano Arifin (202332007) - Manajemen Profesional v7 - Perbaikan Kueri -->
<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: ../admin/login_admin.php');
    exit;
}
include '../config/koneksi.php';
date_default_timezone_set('Asia/Jakarta');
$today = date('Y-m-d');

// --- Logika Update Status ---
if (isset($_POST['update_status'])) {
    $id_booking = $_POST['id_booking'];
    $status = $_POST['status'];
    $stmt = $koneksi->prepare("UPDATE jadwal_booking SET status = ? WHERE id_booking = ?");
    $stmt->bind_param("si", $status, $id_booking);
    $stmt->execute();
    $stmt->close();
    $_SESSION['pesan_sukses'] = "Status booking #$id_booking berhasil diubah.";
    $anchor = strpos($_SERVER['HTTP_REFERER'], '#history') ? '#history' : '#upcoming';
    header("Location: read.php" . $anchor);
    exit;
}

// --- Logika Filter ---
$filter_lapangan_upcoming = isset($_GET['lapangan_upcoming']) ? (array)$_GET['lapangan_upcoming'] : [];
$filter_status_upcoming = isset($_GET['status_upcoming']) ? (array)$_GET['status_upcoming'] : [];
$sort_order_upcoming = isset($_GET['sort_upcoming']) && $_GET['sort_upcoming'] == 'asc' ? 'ASC' : 'DESC';

$filter_lapangan_history = isset($_GET['lapangan_history']) ? (array)$_GET['lapangan_history'] : [];
$filter_status_history = isset($_GET['status_history']) ? (array)$_GET['status_history'] : [];
$sort_order_history = isset($_GET['sort_history']) && $_GET['sort_history'] == 'asc' ? 'ASC' : 'DESC';

// PERBAIKAN: Menambahkan status 'menunggu verifikasi'
$query_today = "SELECT b.*, u.nama AS nama_pengguna, l.nama_lapangan FROM jadwal_booking b LEFT JOIN users u ON b.id_user = u.id_user LEFT JOIN lapangan l ON b.id_lapangan = l.id_lapangan WHERE b.tanggal = ? AND b.status IN ('pending', 'dibayar', 'menunggu verifikasi') ORDER BY b.jam_mulai ASC";
$stmt_today = $koneksi->prepare($query_today);
$stmt_today->bind_param("s", $today);
$stmt_today->execute();
$result_today = $stmt_today->get_result();

// PERBAIKAN: Menambahkan status 'menunggu verifikasi'
$query_upcoming = "SELECT b.*, u.nama AS nama_pengguna, l.nama_lapangan FROM jadwal_booking b LEFT JOIN users u ON b.id_user = u.id_user LEFT JOIN lapangan l ON b.id_lapangan = l.id_lapangan WHERE b.tanggal > '$today'";
if (!empty($filter_lapangan_upcoming)) $query_upcoming .= " AND b.id_lapangan IN (" . implode(',', array_map('intval', $filter_lapangan_upcoming)) . ")";
if (!empty($filter_status_upcoming)) {
    $query_upcoming .= " AND b.status IN ('" . implode("','", array_map('htmlspecialchars', $filter_status_upcoming)) . "')";
} else {
    // Menambahkan 'menunggu verifikasi' ke kondisi default
    $query_upcoming .= " AND b.status IN ('pending', 'dibayar', 'menunggu verifikasi')";
}
$query_upcoming .= " ORDER BY b.tanggal $sort_order_upcoming, b.jam_mulai ASC";
$result_upcoming = $koneksi->query($query_upcoming);

// PERBAIKAN: Menambahkan 'ditolak' ke riwayat dan menggunakan LEFT JOIN
$query_history = "SELECT b.*, u.nama AS nama_pengguna, l.nama_lapangan FROM jadwal_booking b LEFT JOIN users u ON b.id_user = u.id_user LEFT JOIN lapangan l ON b.id_lapangan = l.id_lapangan";
$history_conditions = [];
if (!empty($filter_lapangan_history)) $history_conditions[] = "b.id_lapangan IN (" . implode(',', array_map('intval', $filter_lapangan_history)) . ")";
$status_conditions = [];
if (!empty($filter_status_history)) {
    if (in_array('selesai', $filter_status_history)) $status_conditions[] = "(b.tanggal < '$today' AND b.status = 'dibayar')";
    if (in_array('batal', $filter_status_history)) $status_conditions[] = "b.status = 'batal'";
    if (in_array('ditolak', $filter_status_history)) $status_conditions[] = "b.status = 'ditolak'";
}
if (!empty($status_conditions)) {
    $history_conditions[] = "(" . implode(' OR ', $status_conditions) . ")";
} else {
    // Menambahkan 'ditolak' ke kondisi default
    $history_conditions[] = "((b.tanggal < '$today' AND b.status = 'dibayar') OR b.status IN ('batal', 'ditolak'))";
}
if (!empty($history_conditions)) $query_history .= " WHERE " . implode(' AND ', $history_conditions);
$query_history .= " ORDER BY b.tanggal $sort_order_history, b.jam_mulai ASC";
$result_history = $koneksi->query($query_history);

?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Booking</title>
    <link rel="stylesheet" href="../assets/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <style>
        body { display: flex; min-height: 100vh; background-color: #f8f9fa; }
        .sidebar { width: 280px; background: #212529; color: white; position: fixed; height: 100%; padding-top: 1rem; }
        .sidebar .nav-link { color: #adb5bd; font-size: 1rem; padding: 0.75rem 1.5rem; transition: all 0.3s; }
        .sidebar .nav-link:hover, .sidebar .nav-link.active { background-color: #495057; color: white; border-left: 4px solid #0d6efd; }
        .main-content { margin-left: 280px; padding: 2rem; width: calc(100% - 280px); }
        .dropdown-menu-scrollable { max-height: 200px; overflow-y: auto; }
    </style>
</head>
<body>

<?php include '../admin/templates/sidebar.php'; ?>

<div class="main-content">
    <div class="d-flex justify-content-between align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Manajemen Data Booking</h1>
        <a href="create.php" class="btn btn-primary"><i class="bi bi-plus-circle"></i> Tambah Booking</a>
    </div>

    <?php if (isset($_SESSION['pesan_sukses'])): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert"><?= $_SESSION['pesan_sukses']; ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>
        <?php unset($_SESSION['pesan_sukses']); ?>
    <?php endif; ?>

    <div class="card shadow-sm mb-4">
        <div class="card-header bg-primary text-white"><h5 class="mb-0"><i class="bi bi-calendar-check-fill me-2"></i>Prioritas: Jadwal Aktif Hari Ini</h5></div>
        <div class="card-body p-0"><div class="table-responsive"><table class="table table-hover align-middle mb-0"><?php include 'templates/booking_table.php'; display_booking_table($result_today, $koneksi); ?></table></div></div>
    </div>

    <div class="card shadow-sm mb-4" id="upcoming">
        <div class="card-header"><h5 class="mb-0"><i class="bi bi-calendar-event-fill me-2"></i>Booking Akan Datang</h5></div>
        <div class="card-body">
            <form action="read.php#upcoming" method="GET" class="row g-3 mb-4 p-3 bg-light border rounded align-items-end">
                <div class="col-md-4"><label class="form-label fw-bold">Filter Lapangan</label><div class="dropdown" data-filter-group="lapangan_upcoming"><button class="btn btn-outline-secondary dropdown-toggle w-100 text-start" type="button" data-bs-toggle="dropdown" aria-expanded="false" data-bs-auto-close="outside">Pilih Lapangan...</button><ul class="dropdown-menu dropdown-menu-scrollable w-100"><li><a class="dropdown-item" href="#" onclick="toggleAllCheckboxes(event, 'lapangan_upcoming[]')">Pilih Semua</a></li><li><hr class="dropdown-divider"></li><?php $lap_res = $koneksi->query("SELECT id_lapangan, nama_lapangan FROM lapangan"); while($l = $lap_res->fetch_assoc()): ?><li><label class="dropdown-item"><input class="form-check-input me-2" type="checkbox" name="lapangan_upcoming[]" value="<?= $l['id_lapangan'] ?>" <?= in_array($l['id_lapangan'], $filter_lapangan_upcoming) ? 'checked' : '' ?>> <?= $l['nama_lapangan'] ?></label></li><?php endwhile; ?></ul></div></div>
                <div class="col-md-3"><label class="form-label fw-bold">Filter Status</label><div class="dropdown" data-filter-group="status_upcoming"><button class="btn btn-outline-secondary dropdown-toggle w-100 text-start" type="button" data-bs-toggle="dropdown" aria-expanded="false" data-bs-auto-close="outside">Pilih Status...</button><ul class="dropdown-menu w-100"><li><a class="dropdown-item" href="#" onclick="toggleAllCheckboxes(event, 'status_upcoming[]')">Pilih Semua</a></li><li><hr class="dropdown-divider"></li><li><label class="dropdown-item"><input class="form-check-input me-2" type="checkbox" name="status_upcoming[]" value="pending" <?= in_array('pending', $filter_status_upcoming) ? 'checked' : '' ?>> Pending</label></li><li><label class="dropdown-item"><input class="form-check-input me-2" type="checkbox" name="status_upcoming[]" value="dibayar" <?= in_array('dibayar', $filter_status_upcoming) ? 'checked' : '' ?>> Dibayar</label></li><li><label class="dropdown-item"><input class="form-check-input me-2" type="checkbox" name="status_upcoming[]" value="menunggu verifikasi" <?= in_array('menunggu verifikasi', $filter_status_upcoming) ? 'checked' : '' ?>> Menunggu Verifikasi</label></li></ul></div></div>
                <div class="col-md-3"><label class="form-label fw-bold">Urutkan Tanggal</label><select name="sort_upcoming" class="form-select"><option value="asc" <?= ($sort_order_upcoming == 'ASC') ? 'selected' : '' ?>>Paling Dekat</option><option value="desc" <?= ($sort_order_upcoming == 'DESC') ? 'selected' : '' ?>>Paling Jauh</option></select></div>
                <div class="col-md-2 d-flex align-items-end gap-2"><button type="submit" class="btn btn-info btn-sm w-100">Filter</button><a href="read.php#upcoming" class="btn btn-secondary btn-sm w-100">Reset</a></div>
            </form>
            <div class="table-responsive"><table class="table table-hover align-middle"><?php display_booking_table($result_upcoming, $koneksi); ?></table></div>
        </div>
    </div>

    <div class="card shadow-sm" id="history">
        <div class="card-header"><h5 class="mb-0"><i class="bi bi-archive-fill me-2"></i>Riwayat Pesanan</h5></div>
        <div class="card-body">
            <form action="read.php#history" method="GET" class="row g-3 mb-4 p-3 bg-light border rounded align-items-end">
                <div class="col-md-4"><label class="form-label fw-bold">Filter Lapangan</label><div class="dropdown" data-filter-group="lapangan_history"><button class="btn btn-outline-secondary dropdown-toggle w-100 text-start" type="button" data-bs-toggle="dropdown" data-bs-auto-close="outside">Pilih Lapangan...</button><ul class="dropdown-menu dropdown-menu-scrollable w-100"><li><a class="dropdown-item" href="#" onclick="toggleAllCheckboxes(event, 'lapangan_history[]')">Pilih Semua</a></li><li><hr class="dropdown-divider"></li><?php mysqli_data_seek($lap_res, 0); while($l = $lap_res->fetch_assoc()): ?><li><label class="dropdown-item"><input class="form-check-input me-2" type="checkbox" name="lapangan_history[]" value="<?= $l['id_lapangan'] ?>" <?= in_array($l['id_lapangan'], $filter_lapangan_history) ? 'checked' : '' ?>> <?= $l['nama_lapangan'] ?></label></li><?php endwhile; ?></ul></div></div>
                <div class="col-md-3"><label class="form-label fw-bold">Filter Status</label><div class="dropdown" data-filter-group="status_history"><button class="btn btn-outline-secondary dropdown-toggle w-100 text-start" type="button" data-bs-toggle="dropdown" data-bs-auto-close="outside">Pilih Status...</button><ul class="dropdown-menu w-100"><li><a class="dropdown-item" href="#" onclick="toggleAllCheckboxes(event, 'status_history[]')">Pilih Semua</a></li><li><hr class="dropdown-divider"></li><li><label class="dropdown-item"><input class="form-check-input me-2" type="checkbox" name="status_history[]" value="selesai" <?= in_array('selesai', $filter_status_history) ? 'checked' : '' ?>> Selesai</label></li><li><label class="dropdown-item"><input class="form-check-input me-2" type="checkbox" name="status_history[]" value="batal" <?= in_array('batal', $filter_status_history) ? 'checked' : '' ?>> Batal</label></li><li><label class="dropdown-item"><input class="form-check-input me-2" type="checkbox" name="status_history[]" value="ditolak" <?= in_array('ditolak', $filter_status_history) ? 'checked' : '' ?>> Ditolak</label></li></ul></div></div>
                <div class="col-md-3"><label class="form-label fw-bold">Urutkan Tanggal</label><select name="sort_history" class="form-select"><option value="desc" <?= ($sort_order_history == 'DESC') ? 'selected' : '' ?>>Terbaru</option><option value="asc" <?= ($sort_order_history == 'ASC') ? 'selected' : '' ?>>Terlama</option></select></div>
                <div class="col-md-2 d-flex align-items-end gap-2"><button type="submit" class="btn btn-info btn-sm w-100">Filter</button><a href="read.php#history" class="btn btn-secondary btn-sm w-100">Reset</a></div>
            </form>
            <div class="table-responsive"><table class="table table-hover align-middle"><?php display_booking_table($result_history, $koneksi); ?></table></div>
        </div>
    </div>
</div>

<script src="../assets/dist/js/bootstrap.bundle.min.js"></script>
<script>
function confirmStatusChange(selectElement) {
    const selectedValue = selectElement.value;
    let confirmationText = "";
    if (selectedValue === 'batal') { confirmationText = "PERINGATAN! Mengubah status menjadi 'Batal' adalah tindakan permanen. Lanjutkan?"; }
    else if (selectedValue === 'dibayar') { confirmationText = "KONFIRMASI! Ubah status menjadi 'Dibayar'? Pendapatan akan dicatat. Lanjutkan?"; }
    if (confirmationText) {
        if (confirm(confirmationText)) { selectElement.form.submit(); }
        else { selectElement.options[selectElement.dataset.defaultIndex].selected = true; }
    } else { selectElement.form.submit(); }
}
function toggleAllCheckboxes(event, name) {
    event.preventDefault();
    const menu = event.target.closest('.dropdown-menu');
    const checkboxes = menu.querySelectorAll(`input[name="${name}"]`);
    const isAllChecked = Array.from(checkboxes).every(cb => cb.checked);
    checkboxes.forEach(cb => cb.checked = !isAllChecked);
    updateDropdownButtonText(menu);
}

function updateDropdownButtonText(menu) {
    const dropdownToggle = menu.previousElementSibling;
    const checkboxes = menu.querySelectorAll('input[type="checkbox"]:checked');
    const group = menu.closest('[data-filter-group]').dataset.filterGroup;
    
    let defaultText = 'Pilih...';
    if (group.includes('lapangan')) defaultText = 'Pilih Lapangan...';
    if (group.includes('status')) defaultText = 'Pilih Status...';

    if (checkboxes.length === 0) {
        dropdownToggle.textContent = defaultText;
    } else if (checkboxes.length === 1) {
        dropdownToggle.textContent = checkboxes[0].parentElement.textContent.trim();
    } else {
        const type = group.includes('lapangan') ? 'Lapangan' : 'Status';
        dropdownToggle.textContent = `${checkboxes.length} ${type} Dipilih`;
    }
}

document.querySelectorAll('.dropdown[data-filter-group]').forEach(function (element) {
    const menu = element.querySelector('.dropdown-menu');
    menu.querySelectorAll('input[type="checkbox"]').forEach(cb => {
        cb.addEventListener('change', () => updateDropdownButtonText(menu));
    });
    // Panggil saat load untuk set teks awal
    updateDropdownButtonText(menu);
});
</script>
</body>
</html>
