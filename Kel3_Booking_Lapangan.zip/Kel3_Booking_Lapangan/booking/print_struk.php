<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: ../admin/login_admin.php');
    exit;
}
include '../config/koneksi.php';

$id_booking = isset($_GET['id']) ? intval($_GET['id']) : 0;
if ($id_booking <= 0) {
    die("ID Booking tidak valid.");
}

// Ambil data lengkap untuk struk
$query = "
    SELECT jb.*, u.nama as nama_user, l.nama_lapangan, p.tanggal_bayar
    FROM jadwal_booking jb
    LEFT JOIN users u ON jb.id_user = u.id_user
    LEFT JOIN lapangan l ON jb.id_lapangan = l.id_lapangan
    LEFT JOIN pembayaran p ON jb.id_booking = p.id_booking
    WHERE jb.id_booking = ?
";
$stmt = $koneksi->prepare($query);
$stmt->bind_param("i", $id_booking);
$stmt->execute();
$booking = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$booking) {
    die("Data booking tidak ditemukan.");
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Struk Lunas Booking #<?= $id_booking ?></title>
    <link rel="stylesheet" href="../assets/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Courier+Prime:wght@400;700&display=swap');
        body {
            font-family: 'Courier Prime', monospace;
            background-color: #f0f2f5;
        }
        .receipt-wrapper {
            max-width: 480px;
            margin: 2rem auto;
            padding: 2rem;
            background-color: #fff;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
        }
        .header {
            text-align: center;
            margin-bottom: 1.5rem;
        }
        .header h4 {
            margin: 0;
            font-weight: 700;
        }
        .details-table td {
            padding: 4px 0;
            vertical-align: top;
        }
        .details-table td:first-child {
            width: 120px;
        }
        .total-section {
            margin-top: 1.5rem;
            border-top: 2px dashed #333;
            border-bottom: 2px dashed #333;
            padding: 1rem 0;
            text-align: right;
        }
        .total-section h5 {
            margin: 0;
            font-weight: 700;
            font-size: 1.5rem;
        }
        .paid-stamp {
            text-align: center;
            color: #198754;
            font-size: 2rem;
            font-weight: 700;
            border: 4px solid #198754;
            padding: 0.5rem;
            margin: 1.5rem auto;
            transform: rotate(-10deg);
            width: fit-content;
        }
        .footer {
            text-align: center;
            margin-top: 1.5rem;
            font-size: 0.9rem;
        }
        @media print {
            body { background-color: #fff; }
            .receipt-wrapper {
                margin: 0;
                box-shadow: none;
                max-width: 100%;
            }
            .action-buttons {
                display: none;
            }
        }
    </style>
</head>
<body>

<div class="receipt-wrapper">
    <div class="header">
        <h4>GOR Booking</h4>
        <p class="mb-0">Struk Pembayaran</p>
        <p>====================================</p>
    </div>

    <table class="table table-borderless details-table">
        <tr>
            <td>ID Booking</td>
            <td>: #<?= htmlspecialchars($booking['id_booking']) ?></td>
        </tr>
        <tr>
            <td>Tgl. Bayar</td>
            <td>: <?= date("d M Y, H:i", strtotime($booking['tanggal_bayar'] ?? $booking['created_at'])) ?></td>
        </tr>
        <tr>
            <td>Pemesan</td>
            <td>: <?= htmlspecialchars($booking['nama_user'] ?? 'N/A') ?></td>
        </tr>
    </table>

    <p>------------------------------------</p>
    
    <table class="table table-borderless details-table">
        <tr>
            <td>Lapangan</td>
            <td>: <?= htmlspecialchars($booking['nama_lapangan'] ?? 'N/A') ?></td>
        </tr>
        <tr>
            <td>Jadwal</td>
            <td>: <?= date("d M Y", strtotime($booking['tanggal'])) ?></td>
        </tr>
        <tr>
            <td>Waktu</td>
            <td>: <?= date("H:i", strtotime($booking['jam_mulai'])) ?> - <?= date("H:i", strtotime($booking['jam_selesai'])) ?></td>
        </tr>
    </table>

    <div class="total-section">
        <small>TOTAL DIBAYAR</small>
        <h5>Rp <?= number_format($booking['total_bayar'], 0, ',', '.') ?></h5>
    </div>
    
    <div class="paid-stamp">
        LUNAS
    </div>

    <div class="footer">
        <p>Struk ini adalah bukti pembayaran yang sah. Mohon disimpan dengan baik.</p>
        <p>Terima kasih atas kunjungan Anda.</p>
    </div>
</div>

<div class="text-center my-4 action-buttons">
    <button onclick="window.print()" class="btn btn-primary"><i class="bi bi-printer-fill"></i> Cetak Struk</button>
    <button onclick="window.close()" class="btn btn-secondary">Tutup</button>
</div>

</body>
</html>
