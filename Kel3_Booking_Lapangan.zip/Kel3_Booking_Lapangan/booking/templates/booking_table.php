<?php
// Pastikan fungsi tidak dideklarasikan ulang jika file di-include berkali-kali
if (!function_exists('display_booking_table')) {
    function display_booking_table($result, $koneksi) {
        $today = date('Y-m-d');
?>
    <thead class="table-light">
        <tr>
            <th>ID</th>
            <th>Pemesan</th>
            <th>Detail Booking</th>
            <th>Total Bayar</th>
            <th>Status</th>
            <th class="text-center">Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php if ($result && $result->num_rows > 0): ?>
            <?php 
            while ($row = $result->fetch_assoc()):
                $status_sebenarnya = $row['status'];
                // Otomatis anggap 'selesai' jika sudah dibayar dan tanggalnya lewat
                if ($row['tanggal'] < $today && $status_sebenarnya == 'dibayar') {
                    $status_sebenarnya = 'selesai';
                }

                // Logika untuk warna badge status
                $badge_class = '';
                switch ($status_sebenarnya) {
                    case 'dibayar': $badge_class = 'text-bg-success'; break;
                    case 'pending': $badge_class = 'text-bg-warning'; break;
                    case 'menunggu verifikasi': $badge_class = 'text-bg-info'; break;
                    case 'selesai': $badge_class = 'text-bg-secondary'; break;
                    case 'batal': case 'ditolak': $badge_class = 'text-bg-danger'; break;
                    default: $badge_class = 'text-bg-dark';
                }
            ?>
            <tr>
                <td>#<?= $row['id_booking'] ?></td>
                <td><?= htmlspecialchars($row['nama_pengguna'] ?? 'N/A') ?></td>
                <td>
                    <strong><?= htmlspecialchars($row['nama_lapangan'] ?? 'N/A') ?></strong><br>
                    <small class="text-muted">
                        <?= date("d M Y", strtotime($row['tanggal'])) ?>, 
                        <?= date("H:i", strtotime($row['jam_mulai'])) ?> - <?= date("H:i", strtotime($row['jam_selesai'])) ?>
                    </small>
                </td>
                <td>Rp <?= number_format($row['total_bayar'], 0, ',', '.') ?></td>
                <td>
                    <?php 
                    // PERBAIKAN LOGIKA: Dropdown hanya untuk status 'pending' (booking offline)
                    if ($row['status'] == 'pending'): 
                    ?>
                        <form method='post' action="read.php" class="mb-0">
                            <input type='hidden' name='id_booking' value='<?= $row['id_booking'] ?>'>
                            <input type='hidden' name='update_status' value='1'>
                            <select name='status' class='form-select form-select-sm' onchange='confirmStatusChange(this)'>
                                <option value='pending' selected>Pending</option>
                                <option value='dibayar'>Bayar Sekarang</option>
                                <option value='batal'>Batal</option>
                            </select>
                        </form>
                    <?php else: ?>
                        <!-- Untuk status lain, tampilkan badge statis -->
                        <span class="badge <?= $badge_class ?>"><?= ucfirst(htmlspecialchars($status_sebenarnya)) ?></span>
                    <?php endif; ?>
                </td>
                <td class="text-center">
                    <?php 
                    // PERBAIKAN LOGIKA AKSI: Tombol berbeda untuk setiap status
                    if ($row['status'] == 'pending'): 
                    ?>
                        <a href="print_resi.php?id=<?= $row['id_booking'] ?>" class="btn btn-sm btn-outline-primary" target="_blank" title="Cetak Resi Pembayaran">
                            <i class="bi bi-receipt"></i>
                        </a>
                    <?php elseif ($status_sebenarnya == 'dibayar' || $status_sebenarnya == 'selesai'): ?>
                        <a href="print_struk.php?id=<?= $row['id_booking'] ?>" class="btn btn-sm btn-outline-success" target="_blank" title="Cetak Struk Lunas">
                            <i class="bi bi-printer-fill"></i>
                        </a>
                    <?php else: ?>
                        <!-- Tampilkan strip untuk status 'menunggu verifikasi', 'batal', 'ditolak' -->
                        <span>-</span>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr><td colspan="6" class="text-center text-muted p-4">Tidak ada data untuk ditampilkan.</td></tr>
        <?php endif; ?>
    </tbody>
<?php
    }
}
?>
