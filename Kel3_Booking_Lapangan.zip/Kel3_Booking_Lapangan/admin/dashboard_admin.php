<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: login_admin.php');
    exit;
}
include '../config/koneksi.php';

// --- Bagian Logika & Pengambilan Data ---

$range = isset($_GET['range']) ? $_GET['range'] : 'monthly';
$lapangan_ids_filter = isset($_GET['lapangan_id']) ? (array)$_GET['lapangan_id'] : [];
$today = date('Y-m-d');
$now = date('H:i:s');
$chart_title = 'Bulan Ini';

$start_date = date('Y-m-01');
$end_date = date('Y-m-t');

if ($range == 'daily') { $start_date = $today; $end_date = $today; $chart_title = 'Hari Ini'; }
elseif ($range == 'weekly') { $start_date = date('Y-m-d', strtotime('monday this week')); $end_date = date('Y-m-d', strtotime('sunday this week')); $chart_title = 'Minggu Ini'; }
elseif ($range == 'yearly') { $start_date = date('Y-m-d', strtotime('first day of january this year')); $end_date = date('Y-m-d', strtotime('last day of december this year')); $chart_title = 'Tahun ' . date('Y'); }
elseif ($range == 'all') { $start_date = '2020-01-01'; $end_date = $koneksi->query("SELECT MAX(tanggal) as max_date FROM jadwal_booking")->fetch_assoc()['max_date'] ?? $today; $chart_title = 'Semua Waktu'; }
elseif ($range == 'custom' && isset($_GET['start_date']) && isset($_GET['end_date'])) {
    $start_date = $_GET['start_date']; $end_date = $_GET['end_date'];
    $chart_title = 'Periode Kustom';
}

$where_lapangan = "";
if (!empty($lapangan_ids_filter)) {
    $where_lapangan = " AND jb.id_lapangan IN (" . implode(',', array_map('intval', $lapangan_ids_filter)) . ")";
}

$query_paid = "SELECT jb.total_bayar, jb.tanggal, jb.id_lapangan, jb.created_at FROM jadwal_booking jb WHERE jb.status = 'dibayar' AND jb.tanggal BETWEEN ? AND ? $where_lapangan";
$stmt_paid = $koneksi->prepare($query_paid);
$stmt_paid->bind_param("ss", $start_date, $end_date);
$stmt_paid->execute();
$paid_bookings_res = $stmt_paid->get_result();

$total_pendapatan = 0;
$total_transaksi = $paid_bookings_res->num_rows;

$lapangan_list_query = $koneksi->query("SELECT id_lapangan, nama_lapangan FROM lapangan ORDER BY id_lapangan");
$lapangan_map = [];
$colors = ['#0d6efd', '#198754', '#ffc107', '#dc3545', '#6f42c1', '#fd7e14', '#20c997', '#6610f2'];
$color_index = 0;
while($lap = $lapangan_list_query->fetch_assoc()){
    $lapangan_map[$lap['id_lapangan']] = ['nama' => $lap['nama_lapangan'], 'color' => $colors[$color_index % count($colors)]];
    $color_index++;
}

$period_keys = [];
if ($range == 'yearly' || $range == 'all') {
    $period_start = new DateTime($start_date); $period_end = new DateTime($end_date);
    while($period_start <= $period_end) { $period_keys[$period_start->format('M Y')] = 0; $period_start->modify('+1 month'); }
} else {
    $begin = new DateTime($start_date); $end = new DateTime($end_date); $end->modify('+1 day');
    $interval = DateInterval::createFromDateString('1 day'); $dateRange = new DatePeriod($begin, $interval, $end);
    foreach ($dateRange as $date) { $period_keys[$date->format('d M')] = 0; }
}
$labels = array_keys($period_keys);

foreach ($lapangan_map as $id => &$lap_data) { $lap_data['data'] = $period_keys; }

mysqli_data_seek($paid_bookings_res, 0);
while($booking = $paid_bookings_res->fetch_assoc()) {
    $total_pendapatan += $booking['total_bayar'];
    $key = ($range == 'yearly' || $range == 'all') ? date('M Y', strtotime($booking['tanggal'])) : date('d M', strtotime($booking['tanggal']));
    if (isset($lapangan_map[$booking['id_lapangan']]) && array_key_exists($key, $lapangan_map[$booking['id_lapangan']]['data'])) {
        $lapangan_map[$booking['id_lapangan']]['data'][$key] += $booking['total_bayar'];
    }
}

$query_popular = "SELECT l.id_lapangan, COUNT(jb.id_booking) AS jumlah_booking FROM jadwal_booking jb JOIN lapangan l ON jb.id_lapangan = l.id_lapangan WHERE jb.status = 'dibayar' AND jb.tanggal BETWEEN ? AND ? $where_lapangan GROUP BY l.id_lapangan ORDER BY jumlah_booking DESC LIMIT 5";
$stmt_popular = $koneksi->prepare($query_popular);
$stmt_popular->bind_param("ss", $start_date, $end_date);
$stmt_popular->execute();
$res_popular_fields = $stmt_popular->get_result();

$popular_fields_labels = []; $popular_fields_data = []; $popular_fields_colors = [];
while ($row = $res_popular_fields->fetch_assoc()) {
    $popular_fields_labels[] = $lapangan_map[$row['id_lapangan']]['nama'];
    $popular_fields_data[] = $row['jumlah_booking'];
    $popular_fields_colors[] = $lapangan_map[$row['id_lapangan']]['color'];
}

$upcoming_bookings_count = $koneksi->query("SELECT COUNT(*) AS total FROM jadwal_booking WHERE tanggal > '$today' AND status IN ('pending', 'dibayar', 'menunggu verifikasi')")->fetch_assoc()['total'];
$pending_today_count = $koneksi->query("SELECT COUNT(*) AS total FROM jadwal_booking WHERE tanggal = '$today' AND status IN ('pending', 'menunggu verifikasi')")->fetch_assoc()['total'];

$query_realtime = "SELECT l.nama_lapangan, l.jenis_lapangan, u.nama as nama_pemesan, u.email, u.no_hp, jb.jam_mulai, jb.jam_selesai FROM lapangan l LEFT JOIN jadwal_booking jb ON l.id_lapangan = jb.id_lapangan AND jb.tanggal = ? AND jb.status = 'dibayar' AND ? BETWEEN jb.jam_mulai AND jb.jam_selesai LEFT JOIN users u ON jb.id_user = u.id_user ORDER BY l.id_lapangan";
$stmt_realtime = $koneksi->prepare($query_realtime);
$stmt_realtime->bind_param("ss", $today, $now);
$stmt_realtime->execute();
$realtime_status = $stmt_realtime->get_result();

$res_latest_bookings = $koneksi->query("SELECT jb.id_booking, jb.tanggal, jb.total_bayar, jb.status, u.nama, l.nama_lapangan FROM jadwal_booking jb LEFT JOIN users u ON jb.id_user = u.id_user LEFT JOIN lapangan l ON jb.id_lapangan = l.id_lapangan ORDER BY jb.created_at DESC LIMIT 5");

if (!function_exists('display_simple_booking_table')) {
    function display_simple_booking_table($result) {
?>
        <thead class="table-light">
            <tr>
                <th class="ps-3">ID</th>
                <th>Pemesan</th>
                <th>Lapangan</th>
                <th>Total Bayar</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($result && $result->num_rows > 0):
                while ($row = $result->fetch_assoc()):
                    $status = $row['status'];
                    $badge_class = 'text-bg-secondary';
                    switch ($status) {
                        case 'dibayar': $badge_class = 'text-bg-success'; break;
                        case 'pending': $badge_class = 'text-bg-warning'; break;
                        case 'menunggu verifikasi': $badge_class = 'text-bg-info'; break;
                        case 'batal': $badge_class = 'text-bg-danger'; break;
                        case 'ditolak': $badge_class = 'text-bg-danger'; break;
                    }
            ?>
            <tr>
                <td class="ps-3">#<?= $row['id_booking'] ?></td>
                <td><?= htmlspecialchars($row['nama'] ?? 'N/A') ?></td>
                <td><?= htmlspecialchars($row['nama_lapangan'] ?? 'N/A') ?></td>
                <td>Rp <?= number_format($row['total_bayar'], 0, ',', '.') ?></td>
                <td><span class="badge <?= $badge_class ?>"><?= ucfirst(htmlspecialchars($status)) ?></span></td>
            </tr>
            <?php endwhile; else: ?>
            <tr><td colspan="5" class="text-center text-muted p-4">Tidak ada aktivitas terbaru.</td></tr>
            <?php endif; ?>
        </tbody>
<?php
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin</title>
    <link rel="stylesheet" href="../assets/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body { display: flex; min-height: 100vh; background-color: #f8f9fa; }
        .sidebar { width: 280px; background: #212529; color: white; position: fixed; height: 100%; padding-top: 1rem; }
        .sidebar .nav-link { color: #adb5bd; font-size: 1rem; padding: 0.75rem 1.5rem; transition: all 0.3s; }
        .sidebar .nav-link:hover, .sidebar .nav-link.active { background-color: #495057; color: white; border-left: 4px solid #0d6efd; }
        .main-content { margin-left: 280px; padding: 2rem; width: calc(100% - 280px); }
        .stat-card .card-title { font-size: 0.9rem; font-weight: 600; color: #6c757d; }
        .stat-card .display-6 { font-weight: 700; font-size: 1.75rem; }
        .dropdown-menu-scrollable { max-height: 200px; overflow-y: auto; }
        .card.h-100 { display: flex; flex-direction: column; }
        .card-body.chart-body { flex-grow: 1; display: flex; align-items: center; justify-content: center; }
        .chart-container { position: relative; width: 100%; height: 100%; max-height: 350px; }

        /* PERBAIKAN: Animasi untuk kartu yang perlu perhatian */
        @keyframes pulse-danger {
            0% { box-shadow: 0 0 0 0 rgba(220, 53, 69, 0.7); }
            70% { box-shadow: 0 0 0 10px rgba(220, 53, 69, 0); }
            100% { box-shadow: 0 0 0 0 rgba(220, 53, 69, 0); }
        }
        .stat-card-urgent {
            background-color: #f8d7da;
            animation: pulse-danger 2s infinite;
        }
    </style>
</head>
<body>

<?php include 'templates/sidebar.php'; ?>

<div class="main-content">
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Dashboard</h1>
        <span class="text-muted"><?= date('l, j F Y') ?></span>
    </div>
    
    <div class="card shadow-sm mb-4">
        <div class="card-body">
            <form id="filterForm" class="row g-3 align-items-end">
                <div class="col-lg-5"><label class="form-label">Rentang Waktu</label><div class="btn-group w-100"><a href="?range=daily" class="btn btn-sm <?= $range == 'daily' ? 'btn-primary' : 'btn-outline-secondary' ?>">Hari Ini</a><a href="?range=weekly" class="btn btn-sm <?= $range == 'weekly' ? 'btn-primary' : 'btn-outline-secondary' ?>">Minggu Ini</a><a href="?range=monthly" class="btn btn-sm <?= $range == 'monthly' ? 'btn-primary' : 'btn-outline-secondary' ?>">Bulan Ini</a><a href="?range=yearly" class="btn btn-sm <?= $range == 'yearly' ? 'btn-primary' : 'btn-outline-secondary' ?>">Tahun Ini</a><a href="?range=all" class="btn btn-sm <?= $range == 'all' ? 'btn-primary' : 'btn-outline-secondary' ?>">Semua</a><button type="button" id="customRangeBtn" class="btn btn-sm <?= $range == 'custom' ? 'btn-primary' : 'btn-outline-secondary' ?>"><i class="bi bi-calendar-range"></i></button></div></div>
                <div class="col-lg-4"><label class="form-label">Spesifik Lapangan</label><div class="dropdown" data-filter-group="lapangan_id"><button class="btn btn-outline-secondary dropdown-toggle w-100 text-start" type="button" data-bs-toggle="dropdown" aria-expanded="false" data-bs-auto-close="outside">Pilih Lapangan...</button><ul class="dropdown-menu dropdown-menu-scrollable w-100"><li><a class="dropdown-item" href="#" onclick="toggleAllCheckboxes(event, 'lapangan_id[]')">Pilih Semua</a></li><li><hr class="dropdown-divider"></li><?php mysqli_data_seek($lapangan_list_query, 0); while($l = $lapangan_list_query->fetch_assoc()): ?><li><label class="dropdown-item"><input class="form-check-input me-2" type="checkbox" name="lapangan_id[]" value="<?= $l['id_lapangan'] ?>" <?= in_array($l['id_lapangan'], $lapangan_ids_filter) ? 'checked' : '' ?>> <?= $l['nama_lapangan'] ?></label></li><?php endwhile; ?></ul></div></div>
                <div class="col-lg-3 d-flex align-items-end">
                    <div class="d-flex w-100 gap-2">
                        <button type="submit" class="btn btn-info flex-grow-1"><i class="bi bi-funnel-fill"></i> Terapkan</button>
                        <a href="laporan_pendapatan.php?range=<?= $range ?>&lapangan_id=<?= implode(',', $lapangan_ids_filter) ?>&start_date=<?= $start_date ?>&end_date=<?= $end_date ?>" target="_blank" class="btn btn-success" title="Cetak Laporan"><i class="bi bi-printer-fill"></i></a>
                    </div>
                </div>
                <div class="col-12 mt-3" id="customDateRow" style="display: <?= $range == 'custom' ? 'flex' : 'none' ?>;"><div class="row w-100 g-3 align-items-end"><div class="col-lg-5"><label class="form-label">Tanggal Mulai</label><input type="date" name="start_date" class="form-control" value="<?= $start_date ?>"></div><div class="col-lg-5"><label class="form-label">Tanggal Selesai</label><input type="date" name="end_date" class="form-control" value="<?= $end_date ?>"></div><div class="col-lg-2 d-grid"><button type="submit" name="range" value="custom" class="btn btn-info">Terapkan</button></div></div></div>
            </form>
        </div>
    </div>

    <div class="row mb-4">
        <div class="col-xl-3 col-md-6 mb-3"><div class="card stat-card border-primary h-100"><div class="card-body"><h5 class="card-title text-uppercase">Total Pendapatan (<?= $range != 'custom' ? $chart_title : '' ?>)</h5><p class="card-text display-6">Rp <?= number_format($total_pendapatan, 0, ',', '.') ?></p></div></div></div>
        <div class="col-xl-3 col-md-6 mb-3"><div class="card stat-card border-success h-100"><div class="card-body"><h5 class="card-title text-uppercase">Transaksi</h5><p class="card-text display-6"><?= $total_transaksi ?></p></div></div></div>
        <div class="col-xl-3 col-md-6 mb-3"><div class="card stat-card border-info h-100"><div class="card-body"><h5 class="card-title text-uppercase">Akan Datang</h5><p class="card-text display-6"><?= $upcoming_bookings_count ?></p></div></div></div>
        
        <!-- PERBAIKAN: Kartu "Perlu Tindakan" dengan gaya dinamis -->
        <?php $urgent_class = $pending_today_count > 0 ? 'stat-card-urgent' : ''; ?>
        <div class="col-xl-3 col-md-6 mb-3">
            <div class="card stat-card h-100 <?= $urgent_class ?>">
                <div class="card-body">
                    <h5 class="card-title text-uppercase">Perlu Tindakan Hari Ini</h5>
                    <p class="card-text display-6"><?= $pending_today_count ?></p>
                </div>
            </div>
        </div>
    </div>
    
    <div class="row mb-4">
        <div class="col-lg-7 mb-4 d-flex">
            <div class="card shadow-sm h-100 w-100">
                <div class="card-header d-flex justify-content-between align-items-center"><span><i class="bi bi-bar-chart-line-fill me-2"></i>Grafik Pendapatan (<?= $range != 'custom' ? $chart_title : '' ?>)</span><div class="btn-group btn-group-sm"><button type="button" class="btn btn-outline-secondary active" onclick="changeChartType('bar', this)"><i class="bi bi-bar-chart"></i></button><button type="button" class="btn btn-outline-secondary" onclick="changeChartType('line', this)"><i class="bi bi-graph-up"></i></button></div></div>
                <div class="card-body chart-body">
                    <div class="chart-container"><canvas id="incomeChart"></canvas></div>
                </div>
            </div>
        </div>
        <div class="col-lg-5 mb-4 d-flex">
            <div class="card shadow-sm h-100 w-100">
                <div class="card-header"><i class="bi bi-pie-chart-fill me-2"></i>Lapangan Terpopuler (<?= $range != 'custom' ? $chart_title : '' ?>)</div>
                <div class="card-body chart-body">
                    <div class="chart-container"><canvas id="popularFieldsChart"></canvas></div>
                </div>
            </div>
        </div>
    </div>

    <div class="card shadow-sm mb-4">
        <div class="card-header d-flex justify-content-between align-items-center"><h5 class="mb-0"><i class="bi bi-broadcast me-2"></i>Status Lapangan Saat Ini</h5><span class="badge bg-dark" id="realtime-clock"></span></div>
        <div class="card-body"><div class="row"><?php if ($realtime_status->num_rows > 0): while($status = $realtime_status->fetch_assoc()): $is_used = !is_null($status['nama_pemesan']); ?><div class="col-md-6 mb-3"><div class="card h-100 <?= $is_used ? 'border-danger' : 'border-success' ?>"><div class="card-body"><div class="d-flex justify-content-between"><h6 class="card-title fw-bold"><?= htmlspecialchars($status['nama_lapangan']) ?> <span class="badge bg-secondary"><?= htmlspecialchars($status['jenis_lapangan']) ?></span></h6><span class="badge <?= $is_used ? 'bg-danger' : 'bg-success' ?>"><?= $is_used ? 'Digunakan' : 'Tersedia' ?></span></div><?php if($is_used): ?><small class="text-muted d-block"><i class="bi bi-person-fill"></i> <strong><?= htmlspecialchars($status['nama_pemesan']) ?></strong></small><small class="text-muted d-block"><i class="bi bi-envelope-fill"></i> <?= htmlspecialchars($status['email']) ?> | <i class="bi bi-telephone-fill"></i> <?= htmlspecialchars($status['no_hp']) ?></small><small class="text-muted d-block"><i class="bi bi-clock-fill"></i> <?= date('H:i', strtotime($status['jam_mulai'])) ?> - <?= date('H:i', strtotime($status['jam_selesai'])) ?></small><?php else: ?><small class="text-muted">Tidak ada jadwal aktif saat ini.</small><?php endif; ?></div></div></div><?php endwhile; else: ?><p class="text-center text-muted">Tidak ada data lapangan.</p><?php endif; ?></div></div>
    </div>

    <div class="card shadow-sm">
        <div class="card-header"><i class="bi bi-clock-history me-2"></i>Aktivitas Booking Terbaru</div>
        <div class="card-body p-0"><div class="table-responsive"><table class="table table-hover align-middle mb-0"><?php display_simple_booking_table($res_latest_bookings); ?></table></div></div>
    </div>
</div>

<script src="../assets/dist/js/bootstrap.bundle.min.js"></script>
<script>
    let incomeChart;
    const chartLabels = <?= json_encode($labels) ?>;
    const datasets = <?= json_encode(array_values($lapangan_map)) ?>;

    // PERBAIKAN: Fungsi render chart yang lebih cerdas
    function renderIncomeChart(type = 'bar') {
        if (incomeChart) {
            incomeChart.destroy();
        }
        const ctx = document.getElementById('incomeChart').getContext('2d');

        // Opsi chart dibuat dinamis
        const chartOptions = {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                x: { stacked: type === 'bar' }, // Hanya stack untuk bar chart
                y: { 
                    stacked: type === 'bar', 
                    beginAtZero: true, 
                    ticks: { 
                        callback: function(value) { return 'Rp ' + new Intl.NumberFormat('id-ID').format(value); } 
                    } 
                }
            },
            plugins: {
                tooltip: {
                    mode: 'index',
                    intersect: false,
                },
            },
            interaction: {
                mode: 'index',
                intersect: false,
            }
        };

        // Buat salinan dataset untuk dimodifikasi
        const chartDatasets = JSON.parse(JSON.stringify(datasets)).map(item => {
            let datasetOptions = {
                label: item.nama,
                data: Object.values(item.data),
                borderColor: item.color,
                borderWidth: 1,
                tension: 0.2
            };
            
            // Atur warna berdasarkan tipe chart
            if (type === 'line') {
                // Konversi hex ke rgba untuk area di bawah garis
                let r = parseInt(item.color.slice(1, 3), 16);
                let g = parseInt(item.color.slice(3, 5), 16);
                let b = parseInt(item.color.slice(5, 7), 16);
                datasetOptions.backgroundColor = `rgba(${r}, ${g}, ${b}, 0.2)`;
                datasetOptions.fill = true;
            } else {
                datasetOptions.backgroundColor = item.color;
                datasetOptions.fill = false;
            }
            return datasetOptions;
        });

        incomeChart = new Chart(ctx, {
            type: type,
            data: { labels: chartLabels, datasets: chartDatasets },
            options: chartOptions
        });
    }

    // Fungsi untuk mengganti tipe chart tetap sama
    function changeChartType(type, btn) {
        document.querySelectorAll('.btn-group-sm .btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        renderIncomeChart(type);
    }
    
    // Panggilan awal
    renderIncomeChart('bar');

    const popularCtx = document.getElementById('popularFieldsChart').getContext('2d');
    new Chart(popularCtx, {
        type: 'doughnut',
        data: {
            labels: <?= json_encode($popular_fields_labels) ?>,
            datasets: [{
                label: 'Jumlah Booking',
                data: <?= json_encode($popular_fields_data) ?>,
                backgroundColor: <?= json_encode($popular_fields_colors) ?>,
                hoverOffset: 4
            }]
        },
        options: { responsive: true, maintainAspectRatio: false }
    });

    const clockElement = document.getElementById('realtime-clock');
    function updateClock() { const now = new Date(); const timeString = now.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false }); clockElement.textContent = `Pukul: ${timeString} WIB`; }
    setInterval(updateClock, 1000); updateClock();
    
    document.getElementById('customRangeBtn').addEventListener('click', function() { document.getElementById('customDateRow').style.display = 'flex'; });

    function toggleAllCheckboxes(event, name) {
        event.preventDefault();
        const menu = event.target.closest('.dropdown-menu');
        const checkboxes = menu.querySelectorAll(`input[name="${name}"]`);
        const isAllChecked = Array.from(checkboxes).every(cb => cb.checked);
        checkboxes.forEach(cb => cb.checked = !isAllChecked);
        updateDropdownButtonText(menu);
    }

    function updateDropdownButtonText(menu) {
        const dropdownToggle = menu.previousElementSibling;
        const checkboxes = menu.querySelectorAll('input[type="checkbox"]:checked');
        const group = menu.closest('[data-filter-group]').dataset.filterGroup;
        
        let defaultText = 'Pilih...';
        if (group.includes('lapangan')) defaultText = 'Pilih Lapangan...';

        if (checkboxes.length === 0) {
            dropdownToggle.textContent = defaultText;
        } else if (checkboxes.length === 1) {
            dropdownToggle.textContent = checkboxes[0].parentElement.textContent.trim();
        } else {
            dropdownToggle.textContent = `${checkboxes.length} Lapangan Dipilih`;
        }
    }

    document.querySelectorAll('.dropdown[data-filter-group]').forEach(function (element) {
        const menu = element.querySelector('.dropdown-menu');
        menu.querySelectorAll('input[type="checkbox"]').forEach(cb => {
            cb.addEventListener('change', () => updateDropdownButtonText(element));
        });
        updateDropdownButtonText(menu);
    });
</script>
</body>
</html>
