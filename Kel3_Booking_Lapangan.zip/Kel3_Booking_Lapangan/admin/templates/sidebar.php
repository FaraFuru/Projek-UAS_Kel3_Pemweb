<?php
// Cek apakah session sudah dimulai atau belum
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
// Mendapatkan nama file halaman saat ini untuk menyorot menu aktif
$current_page = basename($_SERVER['PHP_SELF']);
// Mendapatkan path direktori untuk membedakan halaman dengan nama sama
$current_dir = basename(dirname($_SERVER['PHP_SELF']));
?>
<div class="sidebar d-flex flex-column p-3">
    <a href="../admin/dashboard_admin.php" class="d-flex align-items-center mb-3 mb-md-0 me-md-auto text-white text-decoration-none">
        <i class="bi bi-box-seam-fill fs-4 me-2"></i>
        <span class="fs-4">Admin Panel</span>
    </a>
    <hr>
    <ul class="nav nav-pills flex-column mb-auto">
        <li class="nav-item">
            <a href="../admin/dashboard_admin.php" class="nav-link <?= ($current_page == 'dashboard_admin.php') ? 'active' : 'text-white' ?>">
                <i class="bi bi-speedometer2 me-2"></i> Dashboard
            </a>
        </li>
        <li>
            <a href="../booking/read.php" class="nav-link <?= ($current_dir == 'booking') ? 'active' : 'text-white' ?>">
                <i class="bi bi-journal-text me-2"></i> Data Booking
            </a>
        </li>
        <li>
            <a href="../pembayaran/read_pembayaran.php" class="nav-link <?= ($current_dir == 'pembayaran') ? 'active' : 'text-white' ?>">
                <i class="bi bi-credit-card me-2"></i> Verifikasi Pembayaran
            </a>
        </li>
        <li>
            <a href="../lapangan/read_lapangan.php" class="nav-link <?= ($current_dir == 'lapangan') ? 'active' : 'text-white' ?>">
                <i class="bi bi-grid-1x2-fill me-2"></i> Data Lapangan
            </a>
        </li>
        <?php if (isset($_SESSION['admin']) && $_SESSION['admin']['role'] === 'superadmin'): ?>
        <li>
            <a href="../admin/read_admin.php" class="nav-link <?= ($current_page == 'read_admin.php') ? 'active' : 'text-white' ?>">
                <i class="bi bi-people-fill me-2"></i> Kelola Admin
            </a>
        </li>
        <?php endif; ?>
    </ul>
    <hr>
    <div class="dropdown">
        <a href="#" class="d-flex align-items-center text-white text-decoration-none dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
            <i class="bi bi-person-circle me-2"></i>
            <strong><?= isset($_SESSION['admin']) ? htmlspecialchars($_SESSION['admin']['username']) : 'Guest' ?></strong>
        </a>
        <ul class="dropdown-menu dropdown-menu-dark text-small shadow">
            <!-- PERUBAHAN: Link ke halaman profil ditambahkan di sini -->
            <li><a class="dropdown-item" href="../admin/profil.php"><i class="bi bi-person-fill-gear me-2"></i>Profil Saya</a></li>
            <li><hr class="dropdown-divider"></li>
            <li><a class="dropdown-item" href="../admin/logout.php"><i class="bi bi-box-arrow-right me-2"></i>Sign out</a></li>
        </ul>
    </div>
</div>
