<?php
// Pastikan fungsi tidak dideklarasikan ulang
if (!function_exists('display_simple_booking_table')) {
    function display_simple_booking_table($result) {
?>
    <thead class="table-light">
        <tr>
            <th>ID</th>
            <th>Tanggal</th>
            <th>Pemesan</th>
            <th>Lapangan</th>
            <th>Total Bayar</th>
            <th>Status</th>
        </tr>
    </thead>
    <tbody>
        <?php if ($result && $result->num_rows > 0): ?>
            <?php while($row = $result->fetch_assoc()):
                // Logika untuk warna badge status
                $status_class = '';
                if ($row['status'] == 'dibayar') $status_class = 'text-bg-success';
                elseif ($row['status'] == 'pending') $status_class = 'text-bg-warning';
                elseif ($row['status'] == 'batal') $status_class = 'text-bg-danger';
            ?>
            <tr>
                <td>#<?= htmlspecialchars($row['id_booking']) ?></td>
                <td><?= htmlspecialchars(date('d M Y', strtotime($row['tanggal']))) ?></td>
                <td><?= htmlspecialchars($row['nama']) ?></td>
                <td><?= htmlspecialchars($row['nama_lapangan']) ?></td>
                <td>Rp <?= number_format($row['total_bayar'], 0, ',', '.') ?></td>
                <td><span class="badge <?= $status_class ?>"><?= ucfirst($row['status']) ?></span></td>
            </tr>
            <?php endwhile; ?>
        <?php else: ?>
            <tr><td colspan="6" class="text-center text-muted p-4">Belum ada aktivitas booking terbaru.</td></tr>
        <?php endif; ?>
    </tbody>
<?php
    }
}
?>
