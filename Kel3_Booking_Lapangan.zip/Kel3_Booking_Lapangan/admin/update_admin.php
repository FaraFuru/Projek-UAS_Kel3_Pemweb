<!-- Rio Adriano Arifin (202332007) - Ditingkatkan & Lebih Aman -->
<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: login_admin.php');
    exit;
}
include '../config/koneksi.php';

// Keamanan: Cek sesi dan role superadmin
if (!isset($_SESSION['admin']) || $_SESSION['admin']['role'] != 'superadmin') {
    header("Location: login_admin.php");
    exit;
}

// Validasi ID
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: read_admin.php");
    exit;
}

$id_to_edit = intval($_GET['id']);
$current_admin_id = $_SESSION['admin']['id_admin'];

// Ambil data admin yang akan di-edit
$stmt = $koneksi->prepare("SELECT username, nama_admin, email_admin, no_telp_admin, role FROM admin WHERE id_admin = ?");
$stmt->bind_param("i", $id_to_edit);
$stmt->execute();
$result = $stmt->get_result();
$admin = $result->fetch_assoc();
$stmt->close();

if (!$admin) {
    $_SESSION['pesan_error'] = "Admin tidak ditemukan!";
    header("Location: read_admin.php");
    exit;
}

$error_message = '';
// Proses form update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama_admin = $_POST['nama_admin'];
    $email_admin = $_POST['email_admin'];
    $no_telp_admin = $_POST['no_telp_admin'];
    
    $password_to_set = null;
    $new_password_generated = null;

    // Hanya proses reset password jika yang diedit BUKAN diri sendiri
    if (isset($_POST['reset_password']) && $id_to_edit != $current_admin_id) {
        $new_password_generated = 'Admin' . bin2hex(random_bytes(4));
        $password_to_set = $new_password_generated;
    }
    
    $params = [$nama_admin, $email_admin, $no_telp_admin];
    $types = 'sss';
    $sql = "UPDATE admin SET nama_admin = ?, email_admin = ?, no_telp_admin = ?";

    if ($id_to_edit != $current_admin_id) {
        $sql .= ", role = ?";
        $params[] = $_POST['role'];
        $types .= 's';
    }

    if ($password_to_set !== null) {
        $hash = password_hash($password_to_set, PASSWORD_DEFAULT);
        $sql .= ", password = ?";
        $params[] = $hash;
        $types .= 's';
    }
    
    $sql .= " WHERE id_admin = ?";
    $params[] = $id_to_edit;
    $types .= 'i';
    
    $stmt_update = $koneksi->prepare($sql);
    $stmt_update->bind_param($types, ...$params);

    if ($stmt_update->execute()) {
        if ($new_password_generated !== null) {
            $_SESSION['pesan_sukses'] = "Data admin berhasil diupdate. Password baru untuk '" . htmlspecialchars($admin['username']) . "' adalah: <strong>$new_password_generated</strong>";
        } else {
            $_SESSION['pesan_sukses'] = "Data admin berhasil diupdate!";
        }
        header("Location: read_admin.php");
        exit;
    } else {
        $error_message = "Gagal mengupdate data. Error: " . $stmt_update->error;
    }
    $stmt_update->close();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Data Admin</title>
    <link rel="stylesheet" href="../assets/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <style>
        body { display: flex; min-height: 100vh; background-color: #f8f9fa; }
        .sidebar { width: 280px; background: #212529; color: white; position: fixed; height: 100%; padding-top: 1rem; }
        .sidebar .nav-link { color: #adb5bd; font-size: 1rem; padding: 0.75rem 1.5rem; transition: all 0.3s; }
        .sidebar .nav-link:hover, .sidebar .nav-link.active { background-color: #495057; color: white; border-left: 4px solid #0d6efd; }
        .main-content { margin-left: 280px; padding: 2rem; width: calc(100% - 280px); }
    </style>
</head>
<body>

<?php include 'templates/sidebar.php'; ?>

<div class="main-content">
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Edit Admin: <?= htmlspecialchars($admin['username']) ?></h1>
    </div>

    <div class="card shadow-sm" style="max-width: 800px;">
        <div class="card-body p-4">
            <?php if (!empty($error_message)): ?>
                <div class="alert alert-danger"><?= $error_message ?></div>
            <?php endif; ?>
            <form id="updateForm" method="post">
                <div class="mb-3">
                    <label class="form-label">Nama Lengkap</label>
                    <input type="text" name="nama_admin" class="form-control" value="<?= htmlspecialchars($admin['nama_admin']) ?>" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Email</label>
                    <input type="email" name="email_admin" class="form-control" value="<?= htmlspecialchars($admin['email_admin']) ?>" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">No. Telepon</label>
                    <input type="text" name="no_telp_admin" class="form-control" value="<?= htmlspecialchars($admin['no_telp_admin']) ?>" required>
                </div>
                 <div class="mb-3">
                    <label class="form-label">Role</label>
                    <select name="role" id="roleSelect" class="form-select" required <?= ($id_to_edit == $current_admin_id) ? 'disabled' : '' ?>>
                        <option value="admin" <?= $admin['role'] == 'admin' ? 'selected' : '' ?>>Admin</option>
                        <option value="superadmin" <?= $admin['role'] == 'superadmin' ? 'selected' : '' ?>>Superadmin</option>
                    </select>
                </div>

                <!-- PERBAIKAN: Logika Tampilan Password Berdasarkan Siapa yang Diedit -->
                <div class="mb-3">
                    <label class="form-label">Password</label>
                    <?php if ($id_to_edit == $current_admin_id): ?>
                        <!-- Jika superadmin mengedit dirinya sendiri -->
                        <div class="alert alert-info">
                            <i class="bi bi-info-circle-fill me-2"></i>
                            Untuk mengubah password Anda sendiri, silakan gunakan halaman 
                            <a href="profil.php" class="alert-link fw-bold">Profil Saya</a>.
                        </div>
                    <?php else: ?>
                        <!-- Jika superadmin mengedit admin lain -->
                        <div class="alert alert-secondary">
                            <p class="mb-2">Untuk keamanan, password tidak ditampilkan. Jika admin ini lupa password, gunakan tombol di bawah untuk membuat password baru.</p>
                            <button type="submit" name="reset_password" id="resetPasswordBtn" class="btn btn-danger"><i class="bi bi-key-fill"></i> Reset & Ganti Password</button>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="d-flex justify-content-between mt-4">
                    <a href="read_admin.php" class="btn btn-secondary"><i class="bi bi-arrow-left"></i> Kembali</a>
                    <button type="submit" name="update" class="btn btn-warning"><i class="bi bi-save"></i> Update Data</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="../assets/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const roleSelect = document.getElementById('roleSelect');
    if (roleSelect) {
        const originalRole = roleSelect.value;
        roleSelect.addEventListener('change', function() {
            if (this.value === 'superadmin') {
                const confirmation = confirm("PERINGATAN!\n\nAnda akan memberikan hak akses penuh (Superadmin) kepada pengguna ini. Tindakan ini sangat berisiko.\n\nApakah Anda benar-benar yakin?");
                if (!confirmation) {
                    this.value = originalRole;
                }
            }
        });
    }

    const resetBtn = document.getElementById('resetPasswordBtn');
    if(resetBtn) {
        resetBtn.addEventListener('click', function(e) {
            const confirmReset = confirm("Apakah Anda yakin ingin me-reset password untuk admin ini? Tindakan ini akan langsung mengganti password lama dan menyimpan semua perubahan lain pada form.");
            if (!confirmReset) {
                e.preventDefault();
            }
        });
    }
});
</script>
</body>
</html>
