<!-- Rio Adriano Arifin (202332007) - Halaman Profil Admin -->
<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: login_admin.php');
    exit;
}
include '../config/koneksi.php';

$admin_id = $_SESSION['admin']['id_admin'];
$error_message = '';
$success_message = '';

// Proses Update Profil
if (isset($_POST['update_profil'])) {
    $nama = $_POST['nama_admin'];
    $email = $_POST['email_admin'];
    $no_telp = $_POST['no_telp_admin'];

    $stmt = $koneksi->prepare("UPDATE admin SET nama_admin = ?, email_admin = ?, no_telp_admin = ? WHERE id_admin = ?");
    $stmt->bind_param("sssi", $nama, $email, $no_telp, $admin_id);
    if ($stmt->execute()) {
        $success_message = "Profil berhasil diperbarui.";
    } else {
        $error_message = "Gagal memperbarui profil.";
    }
    $stmt->close();
}

// Proses Ganti Password
if (isset($_POST['update_password'])) {
    $pass_lama = $_POST['password_lama'];
    $pass_baru = $_POST['password_baru'];
    $konfirmasi_pass = $_POST['konfirmasi_password'];

    if ($pass_baru !== $konfirmasi_pass) {
        $error_message = "Konfirmasi password baru tidak cocok.";
    } elseif (strlen($pass_baru) < 6) {
        $error_message = "Password baru minimal harus 6 karakter.";
    } else {
        // Ambil hash password saat ini dari DB
        $stmt_pass = $koneksi->prepare("SELECT password FROM admin WHERE id_admin = ?");
        $stmt_pass->bind_param("i", $admin_id);
        $stmt_pass->execute();
        $result_pass = $stmt_pass->get_result()->fetch_assoc();
        $stmt_pass->close();

        // Verifikasi password lama
        if (password_verify($pass_lama, $result_pass['password'])) {
            // Jika valid, hash password baru dan update ke DB
            $hash_baru = password_hash($pass_baru, PASSWORD_DEFAULT);
            $stmt_update_pass = $koneksi->prepare("UPDATE admin SET password = ? WHERE id_admin = ?");
            $stmt_update_pass->bind_param("si", $hash_baru, $admin_id);
            if ($stmt_update_pass->execute()) {
                $success_message = "Password berhasil diganti.";
            } else {
                $error_message = "Gagal mengganti password.";
            }
            $stmt_update_pass->close();
        } else {
            $error_message = "Password lama yang Anda masukkan salah.";
        }
    }
}

// Ambil data terbaru untuk ditampilkan di form
$stmt_data = $koneksi->prepare("SELECT * FROM admin WHERE id_admin = ?");
$stmt_data->bind_param("i", $admin_id);
$stmt_data->execute();
$admin = $stmt_data->get_result()->fetch_assoc();
$stmt_data->close();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil Saya</title>
    <link rel="stylesheet" href="../assets/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <style>
        body { display: flex; min-height: 100vh; background-color: #f8f9fa; }
        .sidebar { width: 280px; background: #212529; color: white; position: fixed; height: 100%; padding-top: 1rem; }
        .sidebar .nav-link { color: #adb5bd; font-size: 1rem; padding: 0.75rem 1.5rem; transition: all 0.3s; }
        .sidebar .nav-link:hover, .sidebar .nav-link.active { background-color: #495057; color: white; border-left: 4px solid #0d6efd; }
        .main-content { margin-left: 280px; padding: 2rem; width: calc(100% - 280px); }
    </style>
</head>
<body>

<?php include 'templates/sidebar.php'; ?>

<div class="main-content">
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Profil Saya</h1>
    </div>

    <?php if (!empty($success_message)): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="bi bi-check-circle-fill me-2"></i> <?= $success_message; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>
    <?php if (!empty($error_message)): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="bi bi-exclamation-triangle-fill me-2"></i> <?= $error_message; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <div class="row">
        <!-- Form Edit Profil -->
        <div class="col-lg-6">
            <div class="card shadow-sm">
                <div class="card-header">
                    <h5 class="mb-0"><i class="bi bi-person-lines-fill me-2"></i>Informasi Pribadi</h5>
                </div>
                <div class="card-body p-4">
                    <form method="post">
                        <div class="mb-3">
                            <label class="form-label">Username</label>
                            <input type="text" class="form-control" value="<?= htmlspecialchars($admin['username']) ?>" disabled readonly>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Nama Lengkap</label>
                            <input type="text" name="nama_admin" class="form-control" value="<?= htmlspecialchars($admin['nama_admin']) ?>" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Email</label>
                            <input type="email" name="email_admin" class="form-control" value="<?= htmlspecialchars($admin['email_admin']) ?>" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">No. Telepon</label>
                            <input type="text" name="no_telp_admin" class="form-control" value="<?= htmlspecialchars($admin['no_telp_admin']) ?>" required>
                        </div>
                        <button type="submit" name="update_profil" class="btn btn-primary w-100"><i class="bi bi-save"></i> Simpan Perubahan Profil</button>
                    </form>
                </div>
            </div>
        </div>

        <!-- Form Ganti Password -->
        <div class="col-lg-6">
            <div class="card shadow-sm">
                <div class="card-header">
                    <h5 class="mb-0"><i class="bi bi-key-fill me-2"></i>Ganti Password</h5>
                </div>
                <div class="card-body p-4">
                    <form method="post">
                        <div class="mb-3">
                            <label class="form-label">Password Lama</label>
                            <input type="password" name="password_lama" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Password Baru</label>
                            <input type="password" name="password_baru" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Konfirmasi Password Baru</label>
                            <input type="password" name="konfirmasi_password" class="form-control" required>
                        </div>
                        <button type="submit" name="update_password" class="btn btn-warning w-100"><i class="bi bi-shield-lock"></i> Ganti Password Saya</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="../assets/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
