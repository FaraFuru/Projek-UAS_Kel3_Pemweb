<!-- Rio Adriano Arifin (202332007) - Laporan Profesional -->
<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: login_admin.php');
    exit;
}
include '../config/koneksi.php';
date_default_timezone_set('Asia/Jakarta');

// --- PENGATURAN FILTER ---
$range = isset($_GET['range']) ? $_GET['range'] : 'monthly';
$lapangan_ids_str = isset($_GET['lapangan_id']) ? $_GET['lapangan_id'] : '';
$start_date = isset($_GET['start_date']) ? $_GET['start_date'] : date('Y-m-01');
$end_date = isset($_GET['end_date']) ? $_GET['end_date'] : date('Y-m-t');

$periode_laporan = 'Periode Kustom';
$nama_lapangan_laporan = 'Semua Lapangan';

// Menentukan judul periode berdasarkan parameter 'range'
if ($range != 'custom') {
    switch ($range) {
        case 'daily': $periode_laporan = 'Harian (' . date('d M Y', strtotime($start_date)) . ')'; break;
        case 'weekly': $periode_laporan = 'Mingguan (' . date('d M Y', strtotime($start_date)) . ' - ' . date('d M Y', strtotime($end_date)) . ')'; break;
        case 'monthly': $periode_laporan = 'Bulanan (' . date('F Y', strtotime($start_date)) . ')'; break;
        case 'yearly': $periode_laporan = 'Tahunan (' . date('Y', strtotime($start_date)) . ')'; break;
        case 'all': $periode_laporan = 'Semua Waktu (Sejak ' . date('d M Y', strtotime($start_date)) . ')'; break;
    }
} else {
    $periode_laporan = 'Periode ' . date('d M Y', strtotime($start_date)) . ' s/d ' . date('d M Y', strtotime($end_date));
}


// --- PENGAMBILAN DATA ---
$where_lapangan = "";
$params = [$start_date, $end_date];
$types = "ss";

if (!empty($lapangan_ids_str)) {
    $lapangan_ids = array_map('intval', explode(',', $lapangan_ids_str));
    if (!empty($lapangan_ids)) {
        $placeholders = implode(',', array_fill(0, count($lapangan_ids), '?'));
        $where_lapangan = " AND jb.id_lapangan IN ($placeholders)";
        $types .= str_repeat('i', count($lapangan_ids));
        $params = array_merge($params, $lapangan_ids);

        // Mengambil nama lapangan untuk judul laporan
        $nama_lap_res = $koneksi->query("SELECT nama_lapangan FROM lapangan WHERE id_lapangan IN (" . implode(',', $lapangan_ids) . ")");
        $nama_list = [];
        while($row = $nama_lap_res->fetch_assoc()) {
            $nama_list[] = $row['nama_lapangan'];
        }
        $nama_lapangan_laporan = implode(', ', $nama_list);
    }
}

$query_paid = "SELECT jb.id_booking, jb.tanggal, jb.total_bayar, u.nama as nama_user, l.nama_lapangan FROM jadwal_booking jb JOIN users u ON jb.id_user = u.id_user JOIN lapangan l ON jb.id_lapangan = l.id_lapangan WHERE jb.status = 'dibayar' AND jb.tanggal BETWEEN ? AND ? $where_lapangan ORDER BY jb.tanggal ASC, jb.jam_mulai ASC";
$stmt_paid = $koneksi->prepare($query_paid);
$stmt_paid->bind_param($types, ...$params);
$stmt_paid->execute();
$transactions = $stmt_paid->get_result();

$total_pendapatan = 0;
$total_transaksi = 0;
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Laporan Pendapatan - <?= strip_tags($periode_laporan) ?></title>
    <link rel="stylesheet" href="../assets/dist/css/bootstrap.min.css">
    <style>
        body { font-family: 'Times New Roman', Times, serif; font-size: 12pt; }
        .report-header { text-align: center; margin-bottom: 30px; border-bottom: 3px double #000; padding-bottom: 15px; }
        .report-header h2, .report-header p { margin: 0; }
        .report-title { text-align: center; margin-bottom: 25px; }
        .report-title h4, .report-title h5 { margin: 5px 0; }
        .signature { margin-top: 60px; text-align: right; }
        .signature p { margin-bottom: 60px; }
        @media print {
            .no-print { display: none; }
            body { -webkit-print-color-adjust: exact !important; color-adjust: exact !important; }
            .table-dark { background-color: #343a40 !important; color: #fff !important; }
        }
    </style>
</head>
<body>
<div class="container mt-4">
    <div class="report-header">
        <h2>Laporan Pendapatan GOR</h2>
        <p>Jl. Peta Utara II No.1, Pegadungan, Kalideres, Kota Jakarta Barat, DKI Jakarta 11840</p>
    </div>

    <div class="report-title">
        <h4>LAPORAN PENDAPATAN</h4>
    </div>

    <table class="mb-3">
        <tr>
            <td style="width: 120px;"><strong>Periode Laporan</strong></td>
            <td>: <?= $periode_laporan ?></td>
        </tr>
        <tr>
            <td><strong>Filter Lapangan</strong></td>
            <td>: <?= $nama_lapangan_laporan ?></td>
        </tr>
    </table>

    <table class="table table-bordered table-sm">
        <thead>
            <tr class="table-light text-center">
                <th style="width: 5%;">No</th>
                <th style="width: 15%;">Tanggal</th>
                <th style="width: 10%;">ID Booking</th>
                <th>Pemesan</th>
                <th>Lapangan</th>
                <th class="text-end" style="width: 20%;">Jumlah (Rp)</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($transactions->num_rows > 0): $no = 1; ?>
                <?php while($row = $transactions->fetch_assoc()): 
                    $total_pendapatan += $row['total_bayar'];
                    $total_transaksi++;
                ?>
                <tr>
                    <td class="text-center"><?= $no++ ?></td>
                    <td><?= date('d M Y', strtotime($row['tanggal'])) ?></td>
                    <td class="text-center">#<?= $row['id_booking'] ?></td>
                    <td><?= htmlspecialchars($row['nama_user']) ?></td>
                    <td><?= htmlspecialchars($row['nama_lapangan']) ?></td>
                    <td class="text-end"><?= number_format($row['total_bayar'], 0, ',', '.') ?></td>
                </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr><td colspan="6" class="text-center p-5">Tidak ada data pendapatan pada periode dan filter yang dipilih.</td></tr>
            <?php endif; ?>
        </tbody>
        <tfoot>
            <tr class="table-dark">
                <th colspan="5" class="text-end">TOTAL PENDAPATAN</th>
                <th class="text-end">Rp <?= number_format($total_pendapatan, 0, ',', '.') ?></th>
            </tr>
        </tfoot>
    </table>

    <div class="row summary-table mt-4">
        <div class="col-4">
            <div class="card">
                <div class="card-body p-2 text-center">
                    <h6 class="card-title mb-1">Total Transaksi</h6>
                    <p class="card-text fs-4 fw-bold mb-0"><?= $total_transaksi ?></p>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-7"></div>
        <div class="col-5 signature">
            <p>Jakarta, <?= date('d F Y') ?></p>
            <p>Mengetahui,</p>
            <br><br>
            <p>( <?= htmlspecialchars($_SESSION['admin']['nama_admin']) ?> )</p>
        </div>
    </div>

    <div class="text-center mt-4 no-print">
        <button onclick="window.print()" class="btn btn-primary"><i class="bi bi-printer-fill me-2"></i>Cetak Laporan</button>
        <a href="dashboard_admin.php" class="btn btn-secondary"><i class="bi bi-arrow-left me-2"></i>Kembali ke Dashboard</a>
    </div>
</div>
<script>
    // Otomatis buka dialog print saat halaman dimuat
    window.onload = function() {
        window.print();
    }
</script>
</body>
</html>
