<!-- Rio Adriano Arifin (202332007) - Ditingkatkan -->
<?php
session_start();
include '../config/koneksi.php';

// Keamanan: Cek sesi dan role superadmin
if (!isset($_SESSION['admin']) || $_SESSION['admin']['role'] != 'superadmin') {
    header("Location: login_admin.php");
    exit;
}

// Validasi ID admin
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    $_SESSION['pesan_error'] = "ID admin tidak valid.";
    header("Location: read_admin.php");
    exit;
}

$id_to_delete = $_GET['id'];
$current_admin_id = $_SESSION['admin']['id_admin'];

// Keamanan: Mencegah superadmin menghapus dirinya sendiri
if ($id_to_delete == $current_admin_id) {
    $_SESSION['pesan_error'] = "Error! Anda tidak dapat menghapus akun Anda sendiri.";
    header("Location: read_admin.php");
    exit;
}

// Gunakan prepared statement untuk keamanan dari SQL Injection
$stmt = $koneksi->prepare("DELETE FROM admin WHERE id_admin = ?");
$stmt->bind_param("i", $id_to_delete);

if ($stmt->execute()) {
    $_SESSION['pesan_sukses'] = "Akun admin berhasil dihapus.";
} else {
    $_SESSION['pesan_error'] = "Gagal menghapus akun admin. Error: " . $stmt->error;
}
$stmt->close();
$koneksi->close();

header("Location: read_admin.php");
exit;
?>
