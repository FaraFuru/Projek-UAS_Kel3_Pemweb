<!-- Rio Adriano Arifin (202332007) - Ditingkatkan & Notifikasi -->
<?php
session_start();
if (!isset($_SESSION['admin']) || $_SESSION['admin']['role'] !== 'superadmin') {
    echo "<script>alert('Akses ditolak! Halaman ini hanya untuk Super Admin.'); location.href='dashboard_admin.php';</script>";
    exit;
}
include '../config/koneksi.php';

$current_admin_id = $_SESSION['admin']['id_admin'];
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Data Admin</title>
    <link rel="stylesheet" href="../assets/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <style>
        body { display: flex; min-height: 100vh; background-color: #f8f9fa; }
        .sidebar { width: 280px; background: #212529; color: white; position: fixed; height: 100%; padding-top: 1rem; }
        .sidebar .nav-link { color: #adb5bd; font-size: 1rem; padding: 0.75rem 1.5rem; transition: all 0.3s; }
        .sidebar .nav-link:hover, .sidebar .nav-link.active { background-color: #495057; color: white; border-left: 4px solid #0d6efd; }
        .main-content { margin-left: 280px; padding: 2rem; width: calc(100% - 280px); }
    </style>
</head>
<body>

<?php include 'templates/sidebar.php'; ?>

<div class="main-content">
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Manajemen Data Admin</h1>
        <a href="register_admin.php" class="btn btn-primary" onclick="return confirm('Anda akan diarahkan ke halaman pendaftaran admin baru. Lanjutkan?')"><i class="bi bi-person-plus-fill"></i> Tambah Admin Baru</a>
    </div>

    <!-- PERBAIKAN: Blok untuk menampilkan notifikasi dari session -->
    <?php if (isset($_SESSION['pesan_sukses'])): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="bi bi-check-circle-fill me-2"></i>
            <?= $_SESSION['pesan_sukses']; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php unset($_SESSION['pesan_sukses']); ?>
    <?php endif; ?>
    <?php if (isset($_SESSION['pesan_error'])): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="bi bi-exclamation-triangle-fill me-2"></i>
            <?= $_SESSION['pesan_error']; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php unset($_SESSION['pesan_error']); ?>
    <?php endif; ?>


    <div class="card shadow-sm">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead class="table-light">
                        <tr>
                            <th>No</th>
                            <th>Username</th>
                            <th>Nama & Kontak</th>
                            <th>Role</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php
                    $no = 1;
                    $result = $koneksi->query("SELECT id_admin, username, nama_admin, email_admin, no_telp_admin, role FROM admin");
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            echo "<tr>
                                <td>{$no}</td>
                                <td><strong>" . htmlspecialchars($row['username']) . "</strong></td>
                                <td>
                                    " . htmlspecialchars($row['nama_admin']) . "<br>
                                    <small class='text-muted'>" . htmlspecialchars($row['email_admin']) . " | " . htmlspecialchars($row['no_telp_admin']) . "</small>
                                </td>
                                <td><span class='badge bg-primary'>" . ucfirst(htmlspecialchars($row['role'])) . "</span></td>
                                <td>";
                            
                            if ($current_admin_id != $row['id_admin']) {
                                echo "<a href='update_admin.php?id={$row['id_admin']}' class='btn btn-sm btn-outline-warning'><i class='bi bi-pencil'></i></a>
                                      <a href='delete_admin.php?id={$row['id_admin']}' class='btn btn-sm btn-outline-danger' onclick='return confirm(\"Yakin ingin hapus admin ini?\")'><i class='bi bi-trash'></i></a>";
                            } else {
                                echo "<a href='update_admin.php?id={$row['id_admin']}' class='btn btn-sm btn-outline-warning'><i class='bi bi-pencil'></i> Edit Profil</a>";
                            }
                            
                            echo "</td></tr>";
                            $no++;
                        }
                    } else {
                        echo "<tr><td colspan='5' class='text-center'>Belum ada data admin.</td></tr>";
                    }
                    ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script src="../assets/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
