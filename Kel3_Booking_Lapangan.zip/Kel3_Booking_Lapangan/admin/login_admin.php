<!-- Rio Adriano Arifin (202332007) -->
<?php
session_start();
include '../config/koneksi.php';

$feedback = '';

if (isset($_POST['login'])) {
    $identifier = $_POST['username'];
    $password   = $_POST['password'];

    $query = $koneksi->query("SELECT * FROM admin WHERE username = '$identifier' OR email_admin = '$identifier'");

    if ($query->num_rows > 0) {
        $admin = $query->fetch_assoc();
        if (password_verify($password, $admin['password'])) {
            $_SESSION['admin'] = $admin;
            $feedback = "<script>
                setTimeout(() => {
                    Swal.fire({
                        icon: 'success',
                        title: 'Login Berhasil!',
                        text: 'Selamat datang, {$admin['nama_admin']}!',
                        timer: 1800,
                        showConfirmButton: false,
                        customClass: { popup: 'glass-alert' },
                        backdrop: 'rgba(0,0,0,0.6)'
                    }).then(() => {
                        document.body.classList.add('fade-out');
                        setTimeout(() => {
                            window.location.href = 'dashboard_admin.php';
                        }, 400);
                    });
                }, 100);
            </script>";
        } else {
            $feedback = "<script>
                setTimeout(() => {
                    Swal.fire({
                        icon: 'error',
                        title: 'Gagal!',
                        text: 'Password salah!',
                        customClass: { popup: 'glass-alert' },
                        backdrop: 'rgba(0,0,0,0.6)'
                    });
                }, 100);
            </script>";
        }
    } else {
        $feedback = "<script>
            setTimeout(() => {
                Swal.fire({
                    icon: 'warning',
                    title: 'Tidak ditemukan!',
                    text: 'Username atau Email tidak cocok!',
                    customClass: { popup: 'glass-alert' },
                    backdrop: 'rgba(0,0,0,0.6)'
                });
            }, 100);
        </script>";
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>👤 Admin Sign In</title>
  <link rel="stylesheet" href="../assets/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="css/style_login.css">
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body>
  <div class="login-card">
    <h2>👤 Admin Sign In</h2>
    <form method="post">
      <div class="mb-3">
        <label class="form-label">Username atau Email</label>
        <input type="text" name="username" class="form-control" placeholder="Masukkan username/email" required>
      </div>
      <div class="mb-3">
        <label class="form-label">Password</label>
        <input type="password" name="password" class="form-control" placeholder="Masukkan password" required>
      </div>
      <div class="d-grid">
        <button type="submit" name="login" class="btn btn-primary mb-2">Login</button>
        <a href="register_admin.php" class="btn btn-outline-light transition-link">Belum punya akun?</a>
      </div>
    </form>
    <div class="footer-text">Login terlebih dahulu untuk mengakses dashboard admin.</div>
  </div>

  <?= $feedback ?>

  <script>
    document.querySelectorAll('.transition-link').forEach(link => {
      link.addEventListener('click', function(e) {
        e.preventDefault();
        document.body.classList.add('fade-out');
        setTimeout(() => {
          window.location.href = this.href;
        }, 500);
      });
    });
  </script>
</body>
</html>
