<!-- Rio Adriano Arifin (202332007) -->
<?php include '../config/koneksi.php'; ?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>🆕 Admin Sign Up</title>
  <link rel="stylesheet" href="../assets/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="css/style_register.css">
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body>
  <div class="register-card">
    <h2>🆕 Admin Sign Up</h2>
    <form method="post">
      <div class="mb-3">
        <label class="form-label">Nama Lengkap</label>
        <input type="text" name="nama_admin" class="form-control" required>
      </div>
      <div class="mb-3">
        <label class="form-label">Email</label>
        <input type="email" name="email_admin" class="form-control" required>
      </div>
      <div class="mb-3">
        <label class="form-label">No. Telepon</label>
        <input type="text" name="no_telp_admin" class="form-control" required>
      </div>
      <div class="mb-3">
        <label class="form-label">Username</label>
        <input type="text" name="username" class="form-control" required>
      </div>
      <div class="mb-3">
        <label class="form-label">Password</label>
        <input type="password" name="password" class="form-control" required>
      </div>
      <div class="mb-3">
        <label class="form-label">Konfirmasi Password</label>
        <input type="password" name="confirm_password" class="form-control" required>
      </div>
      <div class="d-grid">
        <button type="submit" name="register" class="btn btn-success mb-2">Daftar</button>
        <a href="login_admin.php" class="btn btn-outline-light transition-link">Sudah punya akun?</a>
      </div>
    </form>
    <div class="footer-text">Sudah terdaftar? Silakan login sebagai admin.</div>

<?php
if (isset($_POST['register'])) {
    $nama     = $_POST['nama_admin'];
    $email    = $_POST['email_admin'];
    $telp     = $_POST['no_telp_admin'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $confirm  = $_POST['confirm_password'];

    echo "<script>";
    $swalBase = "Swal.fire({customClass:{popup:'glass-alert'},";

    if ($password !== $confirm) {
        echo "{$swalBase} icon:'error', title:'Gagal!', text:'Konfirmasi password tidak cocok!'});";
    } else {
        $cek = $koneksi->query("SELECT * FROM admin WHERE username = '$username' OR email_admin = '$email'");
        if ($cek->num_rows > 0) {
            echo "{$swalBase} icon:'warning', title:'Gagal!', text:'Username atau Email sudah digunakan!'});";
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $query = "INSERT INTO admin (nama_admin, email_admin, no_telp_admin, username, password, role)
                      VALUES ('$nama', '$email', '$telp', '$username', '$hash', 'admin')";
            $koneksi->query($query);
            echo "
              Swal.fire({
                title: 'Sukses!',
                text: 'Registrasi berhasil!',
                icon: 'success',
                timer: 3000,
                showConfirmButton: false,
                customClass: { popup: 'glass-alert' },
                background: 'rgba(255,255,255,0.05)',
                color: '#fff',
                backdrop: 'rgba(0, 0, 0, 0.6)'
              }).then(() => {
                document.body.classList.add('fade-out');
                setTimeout(() => {
                  window.location.href = 'login_admin.php';
                }, 500);
              });
            ";
        }
    }
    echo "</script>";
}
?>
  </div>

  <script>
    // Tambahkan transisi saat klik "Sudah punya akun?"
    document.querySelectorAll('.transition-link').forEach(link => {
      link.addEventListener('click', function(e) {
        e.preventDefault();
        document.body.classList.add('fade-out');
        setTimeout(() => {
          window.location.href = this.href;
        }, 500);
      });
    });
  </script>
</body>
</html>
