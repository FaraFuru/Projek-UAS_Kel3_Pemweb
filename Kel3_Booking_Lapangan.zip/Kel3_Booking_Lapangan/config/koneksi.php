<?php
$host = "localhost";
$user = "root";
$pass = "";
$db   = "kel3_booking_lapangan";

$koneksi = mysqli_connect($host, $user, $pass, $db);
if (!$koneksi) {
    die("Tidak bisa terkoneksi ke database");
}

date_default_timezone_set('Asia/Jakarta');

// --- Logika Pembatalan & Penolakan Otomatis (Lazy Cron) ---

// 1. Batalkan booking PENDING yang tidak dibayar > 15 menit (dari waktu pembuatan)
$koneksi->query("
    UPDATE jadwal_booking 
    SET status = 'batal' 
    WHERE status = 'pending' 
    AND created_at < NOW() - INTERVAL 15 MINUTE
");

// 2. Tolak booking MENUNGGU VERIFIKASI yang tidak diproses admin > 30 menit (dari waktu upload bukti)
$koneksi->query("
    UPDATE jadwal_booking jb
    JOIN pembayaran p ON jb.id_booking = p.id_booking
    SET jb.status = 'ditolak'
    WHERE jb.status = 'menunggu verifikasi'
    AND p.tanggal_bayar < NOW() - INTERVAL 30 MINUTE
");

// --- Akhir Logika Otomatis ---

?>
