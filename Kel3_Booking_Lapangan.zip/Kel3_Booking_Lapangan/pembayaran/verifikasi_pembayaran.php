<?php
session_start();
// Pastikan hanya admin yang bisa mengakses file ini
if (!isset($_SESSION['admin'])) {
    header('Location: ../admin/login_admin.php');
    exit;
}
include '../config/koneksi.php';

// 1. Ambil dan validasi input dari URL
$action = isset($_GET['action']) ? $_GET['action'] : '';
$id_pembayaran = isset($_GET['id']) ? intval($_GET['id']) : 0;

if (empty($action) || $id_pembayaran <= 0) {
    $_SESSION['pesan_error'] = "Aksi tidak valid atau ID pembayaran tidak ditemukan.";
    header('Location: read_pembayaran.php');
    exit;
}

// 2. Dapatkan id_booking yang sesuai dari id_pembayaran untuk update tabel jadwal_booking
$stmt = $koneksi->prepare("SELECT id_booking FROM pembayaran WHERE id_pembayaran = ?");
$stmt->bind_param("i", $id_pembayaran);
$stmt->execute();
$result = $stmt->get_result();
$pembayaran = $result->fetch_assoc();
$stmt->close();

if (!$pembayaran) {
    $_SESSION['pesan_error'] = "Data pembayaran dengan ID tersebut tidak ditemukan.";
    header('Location: read_pembayaran.php');
    exit;
}
$id_booking = $pembayaran['id_booking'];

// 3. Tentukan status baru berdasarkan aksi dari admin
$new_status = '';
if ($action == 'setuju') {
    $new_status = 'dibayar';
    $_SESSION['pesan_sukses'] = "Pembayaran untuk booking #{$id_booking} telah berhasil disetujui.";
} elseif ($action == 'tolak') {
    $new_status = 'ditolak';
    $_SESSION['pesan_sukses'] = "Pembayaran untuk booking #{$id_booking} telah ditolak.";
} else {
    $_SESSION['pesan_error'] = "Aksi tidak dikenal.";
    header('Location: read_pembayaran.php');
    exit;
}

// 4. Update status di tabel jadwal_booking menggunakan prepared statement
$stmt_update = $koneksi->prepare("UPDATE jadwal_booking SET status = ? WHERE id_booking = ?");
$stmt_update->bind_param("si", $new_status, $id_booking);

if (!$stmt_update->execute()) {
    // Jika gagal, set pesan error
    $_SESSION['pesan_error'] = "Terjadi kesalahan saat memperbarui status booking.";
    // Hapus pesan sukses yang mungkin sudah ter-set
    unset($_SESSION['pesan_sukses']);
}
$stmt_update->close();
$koneksi->close();

// 5. Kembalikan admin ke halaman verifikasi
header('Location: read_pembayaran.php');
exit;
?>
