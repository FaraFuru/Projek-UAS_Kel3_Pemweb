<?php
session_start();
include '../config/koneksi.php';

// Cek pesan sukses dari session untuk mencegah refresh/resubmit
$pesan = '';
if (isset($_SESSION['upload_sukses'])) {
    $pesan = 'sukses';
    unset($_SESSION['upload_sukses']);
}

// Ambil ID Booking dari URL
$id_booking = isset($_GET['id']) ? intval($_GET['id']) : 0;
if ($id_booking <= 0) {
    die("Akses tidak valid. ID Booking tidak ditemukan.");
}

// Ambil detail booking untuk ditampilkan, termasuk created_at dan status untuk timer
$stmt_booking = $koneksi->prepare("
    SELECT b.total_bayar, l.nama_lapangan, b.created_at, b.status 
    FROM jadwal_booking b
    LEFT JOIN lapangan l ON b.id_lapangan = l.id_lapangan
    WHERE b.id_booking = ?
");
$stmt_booking->bind_param("i", $id_booking);
$stmt_booking->execute();
$booking_details = $stmt_booking->get_result()->fetch_assoc();
$stmt_booking->close();

if (!$booking_details) {
    die("Booking tidak ditemukan.");
}

// Logika Timer (sama seperti di halaman konfirmasi)
$waktu_dibuat = strtotime($booking_details['created_at']);
$waktu_kedaluwarsa = $waktu_dibuat + (15 * 60); // Batas waktu 15 menit
$waktu_sekarang = time();
$sisa_detik = $waktu_kedaluwarsa - $waktu_sekarang;

// Jika waktu sudah habis saat halaman dimuat, status akan diupdate oleh koneksi.php
// Kita hanya perlu refresh data lokal untuk tampilan
if ($sisa_detik <= 0 && $booking_details['status'] == 'pending') {
    $booking_details['status'] = 'batal';
}

// Proses form saat disubmit
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_FILES['bukti_transfer']) && $_FILES['bukti_transfer']['error'] == 0) {
        $file = $_FILES['bukti_transfer'];
        
        $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
        $max_file_size = 5 * 1024 * 1024; // 5 MB

        if (!in_array($file['type'], $allowed_types)) {
            $pesan = "<div class='alert alert-danger'>Error: Format file tidak didukung. Harap unggah file JPG, PNG, atau GIF.</div>";
        } elseif ($file['size'] > $max_file_size) {
            $pesan = "<div class='alert alert-danger'>Error: Ukuran file terlalu besar. Maksimal 5 MB.</div>";
        } else {
            $upload_dir = '../uploads/';
            $file_extension = pathinfo($file['name'], PATHINFO_EXTENSION);
            $new_filename = 'bukti_' . $id_booking . '_' . time() . '.' . $file_extension;
            $upload_path = $upload_dir . $new_filename;

            if (move_uploaded_file($file['tmp_name'], $upload_path)) {
                $metode_pembayaran = "Transfer Bank";
                $tanggal_bayar = date('Y-m-d H:i:s');
                
                $stmt_insert = $koneksi->prepare("INSERT INTO pembayaran (id_booking, metode_pembayaran, jumlah_bayar, tanggal_bayar, bukti_transfer) VALUES (?, ?, ?, ?, ?)");
                $stmt_insert->bind_param("isdss", $id_booking, $metode_pembayaran, $booking_details['total_bayar'], $tanggal_bayar, $new_filename);
                
                if ($stmt_insert->execute()) {
                    $stmt_update = $koneksi->prepare("UPDATE jadwal_booking SET status = 'menunggu verifikasi' WHERE id_booking = ?");
                    $stmt_update->bind_param("i", $id_booking);
                    $stmt_update->execute();
                    $stmt_update->close();
                    
                    // PERBAIKAN: Set session dan redirect (Pola PRG) untuk mencegah F5/Refresh
                    $_SESSION['upload_sukses'] = true;
                    header("Location: buat_pembayaran.php?id=" . $id_booking);
                    exit;

                } else {
                    $pesan = "<div class='alert alert-danger'>Error: Gagal menyimpan data pembayaran ke database.</div>";
                }
                $stmt_insert->close();
            } else {
                $pesan = "<div class='alert alert-danger'>Error: Gagal memindahkan file yang diunggah.</div>";
            }
        }
    } else {
        $pesan = "<div class='alert alert-danger'>Error: Anda harus memilih file untuk diunggah.</div>";
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <title>Upload Bukti Pembayaran</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../assets/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <style>
      @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap');
      body { font-family: 'Inter', sans-serif; background-color: #f0f2f5; }
      .upload-wrapper { max-width: 600px; margin: 50px auto; }
      .upload-card { border: none; border-radius: 1rem; box-shadow: 0 10px 40px rgba(0,0,0,0.1); }
      .timer-box { font-size: 1.5rem; font-weight: 700; color: #dc3545; }
      .file-drop-area {
          position: relative; display: flex; align-items: center; justify-content: center;
          width: 100%; padding: 40px; border: 2px dashed #ced4da; border-radius: .5rem;
          transition: border-color 0.2s ease-in-out; background-color: #f8f9fa;
      }
      .file-drop-area.is-active { border-color: #0d6efd; }
      .file-input {
          position: absolute; left: 0; top: 0; height: 100%;
          width: 100%; cursor: pointer; opacity: 0;
      }
    </style>
</head>
<body>

<div class="upload-wrapper">
    <div class="card upload-card">
        <div class="card-body p-4 p-md-5">

            <?php if ($pesan == 'sukses'): ?>
                <!-- PERBAIKAN: Tampilan setelah berhasil upload -->
                <div class="text-center">
                    <i class="bi bi-check-circle-fill text-success" style="font-size: 4rem;"></i>
                    <h4 class="fw-bold mt-3">Terima Kasih!</h4>
                    <p class="text-muted">Bukti pembayaran Anda telah berhasil kami terima. Admin akan segera melakukan verifikasi.</p>
                    <p class="text-muted mb-4">Silakan periksa status booking Anda secara berkala di halaman dashboard.</p>
                    <a href="../user/dashboard_lapangan.php" class="btn btn-primary">Kembali ke Dashboard</a>
                </div>

            <?php else: ?>
                <!-- Tampilan FORM atau WAKTU HABIS -->
                <div class="text-center mb-4">
                    <i class="bi bi-cloud-arrow-up-fill text-primary fs-1"></i>
                    <h3 class="fw-bold mt-3">Upload Bukti Pembayaran</h3>
                    <p class="text-muted">Untuk Booking ID: #<?= htmlspecialchars($id_booking) ?></p>
                </div>
                
                <?php if (!empty($pesan)) echo $pesan; // Menampilkan pesan error jika ada ?>

                <?php if ($booking_details['status'] == 'pending'): ?>
                    <!-- Tampilan Form Upload Jika Waktu Masih Ada -->
                    <div id="timer" class="timer-box text-center mb-4">--:--</div>
                    
                    <form id="uploadForm" method="POST" enctype="multipart/form-data">
                        <div class="mb-3">
                            <ul class="list-group list-group-flush mb-4">
                                <li class="list-group-item d-flex justify-content-between align-items-center px-0">
                                    Total Tagihan
                                    <strong class="fs-5 text-primary">Rp <?= number_format($booking_details['total_bayar'], 0, ',', '.') ?></strong>
                                </li>
                                <li class="list-group-item px-0 text-muted small">
                                    <strong>Detail:</strong> <?= htmlspecialchars($booking_details['nama_lapangan'] ?? 'N/A') ?>
                                </li>
                            </ul>
                        </div>
                        <div class="mb-4">
                            <label for="bukti_transfer" class="form-label fw-bold">File Bukti Transfer</label>
                            <div class="file-drop-area">
                                <span class="file-msg">Seret & lepas file di sini, atau klik untuk memilih file</span>
                                <input class="file-input" type="file" name="bukti_transfer" id="bukti_transfer" required>
                            </div>
                            <div class="form-text">Format yang didukung: JPG, PNG, GIF. Ukuran maks: 5MB.</div>
                        </div>
                        <div class="d-grid gap-2">
                            <button type="submit" class="btn btn-primary btn-lg">
                                <i class="bi bi-check-circle-fill me-2"></i>Konfirmasi & Upload
                            </button>
                            <a href="../user/konfirmasi_pembayaran.php?id=<?= $id_booking ?>" class="btn btn-outline-secondary">
                                <i class="bi bi-arrow-left-circle"></i> Kembali & Lihat Nomor VA
                            </a>
                        </div>
                    </form>

                <?php else: ?>
                    <!-- Tampilan Jika Waktu Habis atau Status Tidak Sesuai -->
                    <div class="text-center">
                        <i class="bi bi-x-circle-fill text-danger fs-1"></i>
                        <h3 class="fw-bold mt-3">Tidak Bisa Upload</h3>
                        <p class="text-muted mb-4">Maaf, waktu untuk pembayaran booking ini telah berakhir atau status booking sudah tidak valid lagi.</p>
                        <a href="dashboard_lapangan.php" class="btn btn-outline-secondary w-100">Cari Jadwal Lain</a>
                    </div>
                <?php endif; ?>
            <?php endif; ?>

        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Script untuk timer
    const timerElement = document.getElementById('timer');
    if (timerElement) {
        let remainingSeconds = <?= $sisa_detik > 0 ? $sisa_detik : 0 ?>;

        const interval = setInterval(() => {
            if (remainingSeconds <= 0) {
                clearInterval(interval);
                window.location.reload();
                return;
            }
            
            remainingSeconds--; 
            
            const minutes = Math.floor(remainingSeconds / 60);
            const seconds = remainingSeconds % 60;
            timerElement.textContent = `Sisa Waktu: ${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;

        }, 1000);
    }

    // Script untuk drag-and-drop
    const fileInput = document.querySelector('.file-input');
    if (fileInput) {
        const dropArea = document.querySelector('.file-drop-area');
        const fileMsg = document.querySelector('.file-msg');

        fileInput.addEventListener('change', () => {
            if (fileInput.files.length > 0) {
                fileMsg.textContent = `File dipilih: ${fileInput.files[0].name}`;
                dropArea.classList.add('is-active');
            }
        });

        ['dragenter', 'dragover'].forEach(eventName => {
            dropArea.addEventListener(eventName, (e) => {
                e.preventDefault();
                e.stopPropagation();
                dropArea.classList.add('is-active');
            }, false);
        });

        ['dragleave', 'drop'].forEach(eventName => {
            dropArea.addEventListener(eventName, (e) => {
                e.preventDefault();
                e.stopPropagation();
                dropArea.classList.remove('is-active');
            }, false);
        });

        dropArea.addEventListener('drop', (e) => {
            fileInput.files = e.dataTransfer.files;
            fileMsg.textContent = `File dipilih: ${fileInput.files[0].name}`;
        });
    }
});
</script>

</body>
</html>
