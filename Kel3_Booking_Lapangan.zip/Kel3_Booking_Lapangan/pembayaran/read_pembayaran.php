<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: ../admin/login_admin.php');
    exit;
}
include '../config/koneksi.php';

// PERBAIKAN: Menggunakan LEFT JOIN agar data tetap tampil meskipun user/lapangan terhapus
$query_verifikasi = "
    SELECT p.id_pembayaran, p.id_booking, p.tanggal_bayar, p.bukti_transfer,
           jb.total_bayar, jb.status,
           u.nama as nama_user,
           l.nama_lapangan
    FROM pembayaran p
    JOIN jadwal_booking jb ON p.id_booking = jb.id_booking
    LEFT JOIN users u ON jb.id_user = u.id_user
    LEFT JOIN lapangan l ON jb.id_lapangan = l.id_lapangan
    WHERE jb.status = 'menunggu verifikasi'
    ORDER BY p.tanggal_bayar ASC
";
$res_verifikasi = $koneksi->query($query_verifikasi);

// PERBAIKAN: Menggunakan LEFT JOIN untuk konsistensi
$query_riwayat = "
    SELECT p.id_pembayaran, p.id_booking, p.tanggal_bayar,
           jb.total_bayar, jb.status,
           u.nama as nama_user,
           l.nama_lapangan
    FROM pembayaran p
    JOIN jadwal_booking jb ON p.id_booking = jb.id_booking
    LEFT JOIN users u ON jb.id_user = u.id_user
    LEFT JOIN lapangan l ON jb.id_lapangan = l.id_lapangan
    WHERE jb.status IN ('dibayar', 'ditolak')
    ORDER BY p.tanggal_bayar DESC
    LIMIT 10
";
$res_riwayat = $koneksi->query($query_riwayat);

?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verifikasi Pembayaran</title>
    <link rel="stylesheet" href="../assets/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    
    <style>
        body { display: flex; min-height: 100vh; background-color: #f8f9fa; }
        .sidebar { width: 280px; background: #212529; color: white; position: fixed; height: 100%; padding-top: 1rem; }
        .sidebar .nav-link { color: #adb5bd; font-size: 1rem; padding: 0.75rem 1.5rem; transition: all 0.3s; }
        .sidebar .nav-link:hover, .sidebar .nav-link.active { background-color: #495057; color: white; border-left: 4px solid #0d6efd; }
        .main-content { margin-left: 280px; padding: 2rem; width: calc(100% - 280px); }
        .card { box-shadow: 0 0.5rem 1rem rgba(0,0,0,0.05); border: none; }
        .card-header { font-weight: 600; }
        .alert .bi { vertical-align: middle; }
    </style>
</head>
<body>

<?php include '../admin/templates/sidebar.php'; ?>

<div class="main-content">
    <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Verifikasi Pembayaran</h1>
    </div>

    <!-- Notifikasi -->
    <?php if (isset($_SESSION['pesan_sukses'])): ?>
        <div class="alert alert-success alert-dismissible fade show d-flex align-items-center" role="alert">
            <i class="bi bi-check-circle-fill me-2"></i> 
            <div><?= $_SESSION['pesan_sukses']; ?></div>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php unset($_SESSION['pesan_sukses']); ?>
    <?php endif; ?>
    <?php if (isset($_SESSION['pesan_error'])): ?>
        <div class="alert alert-danger alert-dismissible fade show d-flex align-items-center" role="alert">
            <i class="bi bi-exclamation-triangle-fill me-2"></i>
            <div><?= $_SESSION['pesan_error']; ?></div>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php unset($_SESSION['pesan_error']); ?>
    <?php endif; ?>

    <!-- Tabel Pembayaran Perlu Diverifikasi -->
    <div class="card shadow-sm">
        <div class="card-header">
            <i class="bi bi-patch-check-fill me-2"></i>
            Perlu Diverifikasi
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead>
                        <tr>
                            <th class="ps-3">ID Booking</th>
                            <th>Pemesan</th>
                            <th>Detail</th>
                            <th>Tgl. Bayar</th>
                            <th>Jumlah</th>
                            <th class="text-center">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($res_verifikasi->num_rows > 0): ?>
                            <?php while($row = $res_verifikasi->fetch_assoc()): ?>
                                <tr>
                                    <td class="ps-3"><strong>#<?= htmlspecialchars($row['id_booking']) ?></strong></td>
                                    <td><?= htmlspecialchars($row['nama_user'] ?? 'N/A') ?></td>
                                    <td><?= htmlspecialchars($row['nama_lapangan'] ?? 'N/A') ?></td>
                                    <td><?= date('d M Y, H:i', strtotime($row['tanggal_bayar'])) ?></td>
                                    <td>Rp <?= number_format($row['total_bayar'], 0, ',', '.') ?></td>
                                    <td class="text-center">
                                        <button type="button" class="btn btn-sm btn-outline-info" data-bs-toggle="modal" data-bs-target="#buktiModal-<?= $row['id_pembayaran'] ?>" title="Lihat Bukti">
                                            <i class="bi bi-image"></i>
                                        </button>
                                        <a href="verifikasi_pembayaran.php?action=setuju&id=<?= $row['id_pembayaran'] ?>" class="btn btn-sm btn-outline-success" onclick="return confirm('Anda yakin ingin menyetujui pembayaran ini?')" title="Setujui">
                                            <i class="bi bi-check-lg"></i>
                                        </a>
                                        <a href="verifikasi_pembayaran.php?action=tolak&id=<?= $row['id_pembayaran'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Anda yakin ingin menolak pembayaran ini?')" title="Tolak">
                                            <i class="bi bi-x-lg"></i>
                                        </a>
                                    </td>
                                </tr>

                                <!-- Modal Bukti Pembayaran -->
                                <div class="modal fade" id="buktiModal-<?= $row['id_pembayaran'] ?>" tabindex="-1" aria-labelledby="buktiModalLabel-<?= $row['id_pembayaran'] ?>" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-centered modal-lg">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="buktiModalLabel-<?= $row['id_pembayaran'] ?>">Bukti Pembayaran Booking #<?= $row['id_booking'] ?></h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body text-center">
                                                <img src="../uploads/<?= htmlspecialchars($row['bukti_transfer']) ?>" class="img-fluid rounded" alt="Bukti Transfer" onerror="this.onerror=null;this.src='https://placehold.co/800x600/EEE/31343C?text=Gambar+Tidak+Ditemukan';">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6" class="text-center text-muted p-4">Tidak ada pembayaran yang perlu diverifikasi saat ini.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Tabel Riwayat Pembayaran -->
    <div class="card shadow-sm mt-4">
        <div class="card-header">
            <i class="bi bi-clock-history me-2"></i>
            Riwayat Pembayaran (10 Terbaru)
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead>
                        <tr>
                            <th class="ps-3">ID Booking</th>
                            <th>Pemesan</th>
                            <th>Detail</th>
                            <th>Tgl. Bayar</th>
                            <th>Jumlah</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($res_riwayat->num_rows > 0): ?>
                            <?php while($row = $res_riwayat->fetch_assoc()): ?>
                                <tr>
                                    <td class="ps-3"><strong>#<?= htmlspecialchars($row['id_booking']) ?></strong></td>
                                    <td><?= htmlspecialchars($row['nama_user'] ?? 'N/A') ?></td>
                                    <td><?= htmlspecialchars($row['nama_lapangan'] ?? 'N/A') ?></td>
                                    <td><?= date('d M Y, H:i', strtotime($row['tanggal_bayar'])) ?></td>
                                    <td>Rp <?= number_format($row['total_bayar'], 0, ',', '.') ?></td>
                                    <td>
                                        <?php 
                                            $status_class = 'bg-secondary';
                                            if ($row['status'] == 'dibayar') $status_class = 'bg-success';
                                            if ($row['status'] == 'ditolak') $status_class = 'bg-danger';
                                        ?>
                                        <span class="badge <?= $status_class ?>"><?= ucfirst(htmlspecialchars($row['status'])) ?></span>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6" class="text-center text-muted p-4">Belum ada riwayat pembayaran.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script src="../assets/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
