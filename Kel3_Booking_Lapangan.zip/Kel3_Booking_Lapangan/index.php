<!-- index.php -->
<!DOCTYPE html>
<html>
<head>
  <title>Kel3 Booking Lapangan</title>
  <link rel="stylesheet" href="assets/dist/css/bootstrap.min.css">
  <style>
    body {
      background-color: #f8f9fa;
      height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
    }
    .btn-lg {
      font-size: 1.2rem;
      padding: 1rem 2rem;
    }
  </style>
</head>
<body>

<div class="text-center">
  <h2>Selamat Datang di Sistem Booking Lapangan</h2>
  <p>Pilih akses yang ingin Anda gunakan:</p>
  <div class="d-grid gap-3 mt-4">
    <a href="admin/login_admin.php" class="btn btn-primary btn-lg">👤 Login Admin</a>
    <a href="user/dashboard_lapangan.php" class="btn btn-success btn-lg">🏐 Masuk Sebagai User</a>
  </div>
</div>

</body>
</html>