<!-- Rio Adriano Arifin (202332007) - Ditingkatkan dengan Deskripsi -->
<?php
session_start();
include '../config/koneksi.php';

if (!isset($_SESSION['admin'])) {
    header('Location: ../admin/login_admin.php');
    exit;
}

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: read_lapangan.php");
    exit;
}

$id = intval($_GET['id']);
$stmt = $koneksi->prepare("SELECT * FROM lapangan WHERE id_lapangan = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$lapangan = $result->fetch_assoc();
$stmt->close();

if (!$lapangan) {
    $_SESSION['pesan_error'] = "Data lapangan tidak ditemukan!";
    header("Location: read_lapangan.php");
    exit;
}

$error_message = '';
if (isset($_POST['update'])) {
    $nama = $_POST['nama_lapangan'];
    $jenis = $_POST['jenis_lapangan'];
    $harga = $_POST['harga_per_jam'];
    $deskripsi = $_POST['deskripsi'];
    
    $new_gambar_name = $lapangan['gambar'];

    if (isset($_FILES['gambar']) && $_FILES['gambar']['error'] == 0) {
        $target_dir = "../user/img/";
        $file_extension = strtolower(pathinfo($_FILES["gambar"]["name"], PATHINFO_EXTENSION));
        $file_name = uniqid('lapangan_', true) . '.' . $file_extension;
        $target_file = $target_dir . $file_name;
        $allowed_types = ['jpg', 'jpeg', 'png', 'gif', 'webp'];

        if (in_array($file_extension, $allowed_types)) {
            if (move_uploaded_file($_FILES["gambar"]["tmp_name"], $target_file)) {
                $old_image_path = $target_dir . $lapangan['gambar'];
                if ($lapangan['gambar'] && file_exists($old_image_path)) {
                    unlink($old_image_path);
                }
                $new_gambar_name = $file_name;
            } else {
                $error_message = "Gagal mengupload gambar baru.";
            }
        } else {
            $error_message = "Format file baru tidak didukung.";
        }
    }

    if (empty($error_message)) {
        $stmt_update = $koneksi->prepare("UPDATE lapangan SET nama_lapangan = ?, jenis_lapangan = ?, harga_per_jam = ?, gambar = ?, deskripsi = ? WHERE id_lapangan = ?");
        $stmt_update->bind_param("ssissi", $nama, $jenis, $harga, $new_gambar_name, $deskripsi, $id);
        
        if ($stmt_update->execute()) {
            $_SESSION['pesan_sukses'] = "Data lapangan berhasil diupdate!";
            header("Location: read_lapangan.php");
            exit;
        } else {
            $error_message = "Gagal mengupdate database: " . $stmt_update->error;
        }
        $stmt_update->close();
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Lapangan</title>
    <link rel="stylesheet" href="../assets/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <style>
        body { display: flex; min-height: 100vh; background-color: #f8f9fa; }
        .sidebar { width: 280px; background: #212529; color: white; position: fixed; height: 100%; padding-top: 1rem; }
        .main-content { margin-left: 280px; padding: 2rem; width: calc(100% - 280px); }
    </style>
</head>
<body>

<?php include '../admin/templates/sidebar.php'; ?>

<div class="main-content">
    <div class="d-flex justify-content-between align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Edit Lapangan</h1>
    </div>

    <div class="card shadow-sm" style="max-width: 800px;">
        <div class="card-body p-4">
            <?php if ($error_message): ?>
                <div class="alert alert-danger"><?= $error_message ?></div>
            <?php endif; ?>
            <form method="post" enctype="multipart/form-data">
                <div class="mb-3"><label class="form-label">Nama Lapangan</label><input type="text" name="nama_lapangan" class="form-control" value="<?= htmlspecialchars($lapangan['nama_lapangan']); ?>" required></div>
                <div class="mb-3"><label class="form-label">Jenis Lapangan</label><input type="text" name="jenis_lapangan" class="form-control" value="<?= htmlspecialchars($lapangan['jenis_lapangan']); ?>" required></div>
                <div class="mb-3"><label class="form-label">Deskripsi</label><textarea name="deskripsi" class="form-control" rows="4"><?= htmlspecialchars($lapangan['deskripsi']); ?></textarea><div class="form-text">Gunakan tanda hubung (-) di awal baris untuk membuat daftar poin.</div></div>
                <div class="mb-3"><label class="form-label">Harga Per Jam</label><input type="number" name="harga_per_jam" class="form-control" value="<?= htmlspecialchars($lapangan['harga_per_jam']); ?>" required></div>
                <div class="mb-3"><label class="form-label">Gambar Saat Ini</label><br><?php if ($lapangan['gambar']): ?><img src="../user/img/<?= htmlspecialchars($lapangan['gambar']) ?>" width="200" class="img-thumbnail rounded"><?php endif; ?></div>
                <div class="mb-4"><label class="form-label">Upload Gambar Baru (Kosongkan jika tidak ingin ganti)</label><input type="file" name="gambar" class="form-control" accept="image/*"></div>
                <div class="d-flex justify-content-between"><a href="read_lapangan.php" class="btn btn-secondary"><i class="bi bi-arrow-left"></i> Kembali</a><button type="submit" name="update" class="btn btn-warning"><i class="bi bi-save"></i> Update Data</button></div>
            </form>
        </div>
    </div>
</div>

<script src="../assets/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
