<!-- Rio Adriano Arifin (202332007) - Ditingkatkan dengan Modal Deskripsi -->
<?php 
session_start();
include '../config/koneksi.php';
if (!isset($_SESSION['admin'])) {
    header('Location: ../admin/login_admin.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <title>Data Lapangan</title>
    <link rel="stylesheet" href="../assets/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <style>
        body { display: flex; min-height: 100vh; background-color: #f8f9fa; }
        .sidebar { width: 280px; background: #212529; color: white; position: fixed; height: 100%; padding-top: 1rem; }
        .sidebar .nav-link { color: #adb5bd; font-size: 1rem; padding: 0.75rem 1.5rem; transition: all 0.3s; }
        .sidebar .nav-link:hover, .sidebar .nav-link.active { background-color: #495057; color: white; border-left: 4px solid #0d6efd; }
        .main-content { margin-left: 280px; padding: 2rem; width: calc(100% - 280px); }
    </style>
</head>
<body>

<?php include '../admin/templates/sidebar.php'; ?>

<div class="main-content">
    <div class="d-flex justify-content-between align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Manajemen Data Lapangan</h1>
        <a href="create_lapangan.php" class="btn btn-primary"><i class="bi bi-plus-circle"></i> Tambah Lapangan</a>
    </div>
    
    <div class="card shadow-sm">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead class="table-dark">
                        <tr>
                            <th>No</th>
                            <th>Gambar</th>
                            <th>Nama & Jenis</th>
                            <th>Deskripsi</th>
                            <th>Harga/Jam</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php
                    $no = 1;
                    $result = $koneksi->query("SELECT * FROM lapangan ORDER BY id_lapangan DESC");
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            // PERBAIKAN: Membuat potongan deskripsi
                            $deskripsi_singkat = strlen($row['deskripsi']) > 50 ? substr($row['deskripsi'], 0, 50) . '...' : $row['deskripsi'];
                            
                            echo "<tr>
                                <td>{$no}</td>
                                <td><img src='../user/img/" . htmlspecialchars($row['gambar']) . "' width='120' class='img-thumbnail' alt='Gambar Lapangan'></td>
                                <td><strong>" . htmlspecialchars($row['nama_lapangan']) . "</strong><br><span class='badge bg-info'>" . htmlspecialchars($row['jenis_lapangan']) . "</span></td>
                                <td>
                                    <small>" . htmlspecialchars($deskripsi_singkat) . "</small><br>
                                    <button class='btn btn-link btn-sm p-0' data-bs-toggle='modal' data-bs-target='#detailModal' 
                                            data-nama-lapangan='" . htmlspecialchars($row['nama_lapangan']) . "'
                                            data-deskripsi='" . htmlspecialchars($row['deskripsi']) . "'>
                                        Lihat Detail
                                    </button>
                                </td>
                                <td>Rp " . number_format($row['harga_per_jam'], 0, ',', '.') . "</td>
                                <td>
                                    <a href='update_lapangan.php?id={$row['id_lapangan']}' class='btn btn-sm btn-warning mb-1'><i class='bi bi-pencil-square'></i> Edit</a>
                                    <a href='delete_lapangan.php?id={$row['id_lapangan']}' class='btn btn-sm btn-danger' onclick='return confirm(\"Yakin ingin menghapus lapangan ini?\")'><i class='bi bi-trash'></i> Hapus</a>
                                </td>
                            </tr>";
                            $no++;
                        }
                    } else {
                        echo "<tr><td colspan='6' class='text-center p-4'>Belum ada data lapangan.</td></tr>";
                    }
                    ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Modal untuk Detail Deskripsi -->
<div class="modal fade" id="detailModal" tabindex="-1" aria-labelledby="detailModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="detailModalLabel">Deskripsi Lapangan</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body" id="modal-body-content">
        <!-- Konten akan diisi oleh JavaScript -->
      </div>
    </div>
  </div>
</div>

<script src="../assets/dist/js/bootstrap.bundle.min.js"></script>
<script>
const detailModal = document.getElementById('detailModal');
detailModal.addEventListener('show.bs.modal', function (event) {
    const button = event.relatedTarget;
    const namaLapangan = button.getAttribute('data-nama-lapangan');
    const deskripsi = button.getAttribute('data-deskripsi');
    
    const modalTitle = detailModal.querySelector('.modal-title');
    const modalBody = detailModal.querySelector('.modal-body');

    modalTitle.textContent = 'Deskripsi: ' + namaLapangan;

    // --- PERBAIKAN: Logika untuk memformat deskripsi di JavaScript ---
    let deskripsiHtml = '';
    if (deskripsi.trim()) {
        const lines = deskripsi.split('\\n').join('\n').split('\n');
        lines.forEach(line => {
            const trimmedLine = line.trim();
            if (trimmedLine.startsWith('-')) {
                // Jika baris dimulai dengan '-', buat sebagai list item
                if (!deskripsiHtml.includes('<ul')) {
                    deskripsiHtml += '<ul class="description-list">';
                }
                deskripsiHtml += '<li>' + trimmedLine.substring(1).trim() + '</li>';
            } else if (trimmedLine) {
                // Jika baris bukan list item, tutup <ul> jika ada, lalu buat paragraf baru
                if (deskripsiHtml.includes('<ul')) {
                    deskripsiHtml += '</ul>';
                }
                deskripsiHtml += '<p>' + trimmedLine + '</p>';
            }
        });
        if (deskripsiHtml.includes('<ul') && !deskripsiHtml.endsWith('</ul>')) {
            deskripsiHtml += '</ul>';
        }
    } else {
        deskripsiHtml = '<p class="text-muted">Tidak ada deskripsi.</p>';
    }
    
    modalBody.innerHTML = deskripsiHtml;
});
</script>
</body>
</html>
