<!-- Rio Adriano Arifin (202332007) - Ditingkatkan -->
<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header('Location: ../admin/login_admin.php');
    exit;
}
include '../config/koneksi.php';

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    $_SESSION['pesan_error'] = "ID lapangan tidak valid.";
    header("Location: read_lapangan.php");
    exit;
}

$id = intval($_GET['id']);

// Mulai transaksi untuk memastikan konsistensi
$koneksi->begin_transaction();

try {
    // 1. Cek apakah lapangan masih digunakan di jadwal_booking (dengan prepared statement)
    $stmt_check = $koneksi->prepare("SELECT COUNT(*) as total FROM jadwal_booking WHERE id_lapangan = ?");
    $stmt_check->bind_param("i", $id);
    $stmt_check->execute();
    $result_check = $stmt_check->get_result()->fetch_assoc();
    $stmt_check->close();

    if ($result_check['total'] > 0) {
        // Jika masih ada booking, batalkan operasi
        throw new Exception("Gagal menghapus! Lapangan ini masih memiliki jadwal booking.");
    }

    // 2. Ambil nama file gambar sebelum menghapus data dari database
    $stmt_get_img = $koneksi->prepare("SELECT gambar FROM lapangan WHERE id_lapangan = ?");
    $stmt_get_img->bind_param("i", $id);
    $stmt_get_img->execute();
    $result_img = $stmt_get_img->get_result()->fetch_assoc();
    $gambar_file = $result_img ? $result_img['gambar'] : null;
    $stmt_get_img->close();

    // 3. Hapus data dari database (dengan prepared statement)
    $stmt_delete = $koneksi->prepare("DELETE FROM lapangan WHERE id_lapangan = ?");
    $stmt_delete->bind_param("i", $id);

    if (!$stmt_delete->execute()) {
        throw new Exception("Gagal menghapus data dari database.");
    }
    $stmt_delete->close();
    
    // 4. Hapus file gambar dari server jika ada
    if ($gambar_file) {
        $path_to_image = '../user/img/' . $gambar_file;
        if (file_exists($path_to_image)) {
            unlink($path_to_image);
        }
    }
    
    // Jika semua langkah berhasil, commit transaksi
    $koneksi->commit();
    $_SESSION['pesan_sukses'] = "Data lapangan berhasil dihapus.";

} catch (Exception $e) {
    // Jika terjadi error, batalkan semua perubahan
    $koneksi->rollback();
    $_SESSION['pesan_error'] = $e->getMessage();
}

header("Location: read_lapangan.php");
exit;
?>
