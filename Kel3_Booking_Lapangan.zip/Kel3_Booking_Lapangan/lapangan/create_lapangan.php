<?php
session_start();
include '../config/koneksi.php';

if (!isset($_SESSION['admin'])) {
    header('Location: ../admin/login_admin.php');
    exit;
}

$error_message = '';
if (isset($_POST['simpan'])) {
    $nama = $_POST['nama_lapangan'];
    $jenis = $_POST['jenis_lapangan'];
    $harga = $_POST['harga_per_jam'];
    $deskripsi = $_POST['deskripsi']; // Ambil data deskripsi

    if (empty($nama) || empty($jenis) || empty($harga) || !isset($_FILES["gambar"]) || $_FILES["gambar"]["error"] != 0) {
        $error_message = "Semua field harus diisi, termasuk gambar.";
    } else {
        $target_dir = "../user/img/";
        $file_extension = strtolower(pathinfo($_FILES["gambar"]["name"], PATHINFO_EXTENSION));
        $file_name = uniqid('lapangan_', true) . '.' . $file_extension;
        $target_file = $target_dir . $file_name;
        
        $allowed_types = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
        if (in_array($file_extension, $allowed_types)) {
            if (move_uploaded_file($_FILES["gambar"]["tmp_name"], $target_file)) {
                // PERUBAHAN: Tambahkan 'deskripsi' ke query
                $stmt = $koneksi->prepare("INSERT INTO lapangan (nama_lapangan, jenis_lapangan, harga_per_jam, gambar, deskripsi) VALUES (?, ?, ?, ?, ?)");
                // PERUBAHAN: Tambahkan 's' untuk string deskripsi
                $stmt->bind_param("ssiss", $nama, $jenis, $harga, $file_name, $deskripsi);
                
                if ($stmt->execute()) {
                    $_SESSION['pesan_sukses'] = "Lapangan baru berhasil ditambahkan!";
                    header("Location: read_lapangan.php");
                    exit;
                } else {
                    $error_message = "Gagal menyimpan ke database: " . $stmt->error;
                }
                $stmt->close();
            } else {
                $error_message = "Maaf, terjadi kesalahan saat mengupload file.";
            }
        } else {
            $error_message = "Format file tidak didukung.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Lapangan Baru</title>
    <link rel="stylesheet" href="../assets/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <style>
        body { display: flex; min-height: 100vh; background-color: #f8f9fa; }
        .sidebar { width: 280px; background: #212529; color: white; position: fixed; height: 100%; padding-top: 1rem; }
        .main-content { margin-left: 280px; padding: 2rem; width: calc(100% - 280px); }
    </style>
</head>
<body>

<?php include '../admin/templates/sidebar.php'; ?>

<div class="main-content">
    <div class="d-flex justify-content-between align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Tambah Lapangan Baru</h1>
    </div>

    <div class="card shadow-sm" style="max-width: 800px;">
        <div class="card-body p-4">
            <?php if ($error_message): ?>
                <div class="alert alert-danger"><?= $error_message ?></div>
            <?php endif; ?>
            
            <form method="post" enctype="multipart/form-data">
                <div class="mb-3">
                    <label for="nama_lapangan" class="form-label">Nama Lapangan</label>
                    <input type="text" name="nama_lapangan" id="nama_lapangan" class="form-control" required>
                </div>
                <div class="mb-3">
                    <label for="jenis_lapangan" class="form-label">Jenis Lapangan</label>
                    <input type="text" name="jenis_lapangan" id="jenis_lapangan" class="form-control" placeholder="Contoh: Futsal, Badminton" required>
                </div>
                <div class="mb-3">
                    <label for="deskripsi" class="form-label">Deskripsi Singkat</label>
                    <textarea name="deskripsi" id="deskripsi" class="form-control" rows="3" placeholder="Contoh: Lapangan Futsal indoor dengan rumput sintetis standar internasional."></textarea>
                    <div class="form-text">Gunakan tanda hubung (-) di awal baris untuk membuat daftar poin.</div>
                </div>
                <div class="mb-3">
                    <label for="harga_per_jam" class="form-label">Harga Per Jam</label>
                    <div class="input-group">
                        <span class="input-group-text">Rp</span>
                        <input type="number" name="harga_per_jam" id="harga_per_jam" class="form-control" min="1000" step="1000" required>
                    </div>
                </div>
                <div class="mb-4">
                    <label for="gambar" class="form-label">Gambar Lapangan</label>
                    <input type="file" name="gambar" id="gambar" class="form-control" accept="image/*" required>
                </div>

                <div class="d-flex justify-content-between">
                    <a href="read_lapangan.php" class="btn btn-secondary"><i class="bi bi-x-circle"></i> Batal</a>
                    <button type="submit" name="simpan" class="btn btn-primary"><i class="bi bi-check-circle-fill"></i> Simpan Lapangan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="../assets/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
